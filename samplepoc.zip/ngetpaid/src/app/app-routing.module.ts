import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
 
import { WelcomeComponent } from "./welcome/welcome.component";

const routes: Routes =  [
  {
    path: "",
    children: [
      { path: "welcome", component: WelcomeComponent },
      {
        path: "",
        redirectTo: "/welcome",
        pathMatch: "full"
      },
      {
        path: 'col',  
        loadChildren: './collection/collection.module#CollectionModule'
      }
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes,{ initialNavigation: true, useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
