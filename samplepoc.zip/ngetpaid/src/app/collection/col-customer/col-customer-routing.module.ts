import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@core/services/auth.guard';
import { ColLandingComponent } from './col-landing/col-landing.component';
import { DumbComponent } from '../../shared/dumb/dumb.component';

const routes: Routes = [
  {
    path: '',
    canActivateChild: [AuthGuard],
    component: ColLandingComponent,
    children: [
      {
        path: 'n1Col/:url',
        component: DumbComponent,
        data: { expectedRole: ['GA_ADMIN', 'GP_COLLECTOR'] }
      },
      {
        path: 'home',
        component: DumbComponent,
        pathMatch: 'full',
        data: { expectedRole: ['GA_ADMIN', 'GP_COLLECTOR'] }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CollectionRoutingModule {}
