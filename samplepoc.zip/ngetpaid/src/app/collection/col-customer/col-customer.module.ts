import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ShellModule } from "@ruf/shell";
import { CollectionRoutingModule } from "./col-customer-routing.module";
import { ColLandingComponent } from "./col-landing/col-landing.component";
import { ColPageHeaderComponent } from "./col-page-header/col-page-header.component";
import { ColRouterOutletComponent } from "./col-router-outlet/col-router-outlet.component";
import { SharedModule } from "../../shared/shared.module";
 
@NgModule({
  imports: [CommonModule, CollectionRoutingModule, ShellModule,SharedModule],
  declarations: [
    ColLandingComponent,
    ColPageHeaderComponent,
    ColRouterOutletComponent,
  ]
})
export class CustomerModule {}
