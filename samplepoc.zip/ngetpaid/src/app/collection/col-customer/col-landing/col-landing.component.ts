import { Component, OnInit, HostBinding, OnDestroy } from '@angular/core';

import { Subscription } from 'rxjs/Subscription';
import * as fromCore from '@core/store';
import { Store } from '@ngrx/store';
@Component({
  selector: 'app-col-landing',
  templateUrl: './col-landing.component.html',
  styleUrls: ['./col-landing.component.scss']
})
export class ColLandingComponent implements OnInit, OnDestroy {
  @HostBinding('style.flex-grow') flexGrow = '0';

  constructor(private store: Store<fromCore.State>) {}
  subscription: Subscription;

  ngOnInit() {
    this.subscription = this.store.select(fromCore.getShowAngularJS).subscribe(showAngularjs => {
      if (showAngularjs) {
        this.flexGrow = '0';
      } else {
        this.flexGrow = '1';
      }
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
