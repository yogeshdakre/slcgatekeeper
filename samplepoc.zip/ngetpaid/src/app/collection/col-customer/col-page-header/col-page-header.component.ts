import { Store } from '@ngrx/store';
import * as fromCore from '@core/store';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { DynamicMenubarItem } from '@ruf/shell';
import { Router, ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs/Observable';
import { map, filter } from 'rxjs/operators';
import { NavigationService } from '@core/services/navigation.service';
import { switchMap, distinctUntilChanged, debounceTime } from 'rxjs/operators';
@Component({
  selector: 'app-col-page-header',
  templateUrl: './col-page-header.component.html',
  styleUrls: ['./col-page-header.component.scss']
})
export class ColPageHeaderComponent implements OnInit {
  menus = [
    '0xFFD3',
    '0x9004',
    '0xE87B',
    '0xF626',
    '0x280F',
    'GP_COLLECTION_DSO',
    'GP_FAMILYAGING',
    '0xF6A4',
    'GP_COLLECTION_PAYMENT_INSTR',
    '0xE14D',
    '0xC161',
    '0xBD67',
    '0xBD68',
    '0x2700'
  ];
  path = [
    'col.customer.window1',
    'col.customer.customerSetup',
    'col.customer.dispute',
    'cred.customer.window1',
    'col.customer.aging',
    'col.customer.dso',
    'col.customer.family',
    'col.customer.invoiceHistory',
    'col.customer.paymentInstruments',
    'col.customer.paymentHistory',
    'col.customer.unappliedCashEntry',
    'col.customer.paymentLog',
    'col.customer.advice',
    'col.customer.contact'
  ];
  items: DynamicMenubarItem[];

  firstTime = true;
  showN1$: Observable<boolean>;
  selectedPaths$: Observable<string>;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private translate: TranslateService,
    private store: Store<fromCore.State>,
    private navigationService: NavigationService
  ) {}
  ngOnInit() {
    /*if (this.route.firstChild ) {
      this.selectedPaths$ = this.route.firstChild.url.pipe(
        map(segments => {
        if (segments.length > 0) {
          return segments[segments.length - 1].toString();
        }
      }));
    }*/
    this.showN1$ = this.store.select(fromCore.getShowAngularJS);
    this.selectedPaths$ = this.navigationService.getN1CurrentNavigationNotifiction().pipe(
      // we don't need duplicated path change
      distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)),
      //filter out some we don't need
      filter(val => {
        const url = val['nav'].replace('/col.customer.window/', '');
        // this is a trick part, we skip this one.
        if ('/col.dispute.window' === url || '/blank' === url) {
          return false;
        }
        return true;
      }),
      map(val => {
        const url = val['nav'].replace('/col.customer.window/', '');
        //this.firstTime = true;
        //console.log(url);
        const result = val['nav'].replace('/col.customer.window/', '');
        if (result.startsWith('/col.customer.window') || result.startsWith('col.customer.window1')) {
          return 'col.customer.window1';
        } else {
          return result;
        }
        //return val["nav"].replace("/col.customer.window/", "");
      })
    );
    //console.log(this.menus);
    this.translate.get(this.menus).subscribe(keys => {
      //console.log(keys);
      this.items = [
        { path: this.path[0], label: keys['0xFFD3'] },
        { path: this.path[1], label: keys['0x9004'] },
        { path: this.path[2], label: keys['0xE87B'] },
        { path: this.path[3], label: keys['0xF626'] },
        { path: this.path[4], label: keys['0x280F'] },
        { path: this.path[5], label: keys['GP_COLLECTION_DSO'] },
        { path: this.path[6], label: keys['GP_FAMILYAGING'] },
        { path: this.path[7], label: keys['0xF6A4'] },
        { path: this.path[8], label: keys['GP_COLLECTION_PAYMENT_INSTR'] },
        { path: this.path[9], label: keys['0xE14D'] },
        { path: this.path[10], label: keys['0xC161'] },
        { path: this.path[11], label: keys['0xBD67'] },
        { path: this.path[12], label: keys['0xBD68'] },
        { path: this.path[13], label: keys['0x2700'] },
        { path: 'col/home', label: 'home' }
      ];
    });
  }
  navigateTo($event) {
    if ($event.path === 'col/home') {
      this.navigationService.navigateTo([$event.path]);
      return;
    }
    //console.log(window.event.srcElement);
    // this is a trick part, we dont want to open customer window twice.
    if (!this.firstTime) this.navigationService.navigateToN1('col.customer.window/' + $event.path);
    this.firstTime = false;
  }
}
