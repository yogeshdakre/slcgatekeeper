import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { Store } from '@ngrx/store';

import { ColRouterOutletComponent } from './col-router-outlet.component';

describe('ColRouterOutletComponent', () => {
  let component: ColRouterOutletComponent;
  let fixture: ComponentFixture<ColRouterOutletComponent>;
  let store: { select: jasmine.Spy };
  const subject: Subject<Boolean> = new BehaviorSubject(true);
  beforeEach(
    async(() => {
      store = jasmine.createSpyObj('Store', ['select']);
      //location.path.and.returnValue("");
      TestBed.configureTestingModule({
        declarations: [ColRouterOutletComponent],
        imports: [RouterTestingModule],
        providers: [{ provide: Store, useValue: store }]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    store.select.and.returnValue(subject);
    fixture = TestBed.createComponent(ColRouterOutletComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    //console.log(component);
    expect(component).toBeTruthy();
  });
  it('should display to none when is showangularjs true', () => {
    subject.next(true);
    expect(component.display).toBe('none');
  });
  it('should display to flex when is showangularjs false', () => {
    subject.next(false);
    expect(component.display).toBe('flex');
  });
});
