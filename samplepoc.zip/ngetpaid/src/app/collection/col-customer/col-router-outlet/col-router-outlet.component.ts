import { Store } from '@ngrx/store';
import { Component, OnInit, HostBinding, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import * as fromCore from '@core/store';
@Component({
  selector: 'app-col-router-outlet',
  templateUrl: './col-router-outlet.component.html',
  styleUrls: ['./col-router-outlet.component.scss']
})
export class ColRouterOutletComponent implements OnInit, OnDestroy {
  @HostBinding('style.display') display = 'none';

  constructor(private store: Store<fromCore.State>) {}
  subscription: Subscription;

  ngOnInit() {
    this.subscription = this.store.select(fromCore.getShowAngularJS).subscribe(showAngularjs => {
      if (showAngularjs) {
        this.display = 'none';
      } else {
        this.display = 'flex';
      }
    });
  }
  ngOnDestroy() {
    if (this.subscription != null) {
      this.subscription.unsubscribe();
    }
  }
}
