import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ShellModule } from "@ruf/shell"; 
import { SharedModule } from "../shared/shared.module";
import { CustomerModule } from './col-customer/col-customer.module';

@NgModule({
  imports: [CommonModule,  ShellModule,SharedModule, CustomerModule],
  declarations: [
   
  ]
})
export class CollectionModule {}
