import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GriddemoComponent } from './griddemo.component';

xdescribe('GriddemoComponent', () => {
  let component: GriddemoComponent;
  let fixture: ComponentFixture<GriddemoComponent>;

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        declarations: [GriddemoComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(GriddemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
