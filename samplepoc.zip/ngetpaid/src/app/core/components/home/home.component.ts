import { Component, OnInit } from "@angular/core";
import { IAlert } from "@shared/shared.module";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  public alerts: Array<IAlert> = [];
  constructor() {
    this.alerts.push({
      id: 1,
      type: 'success',
      message: 'This is an success alert',
    }, {
        id: 2,
        type: 'info',
        message: 'This is an info alert',
      }, {
        id: 3,
        type: 'warning',
        message: 'This is a warning alert',
      }, {
        id: 4,
        type: 'error',
        message: 'This is a danger alert',
      }, {
        id: 5,
        type: '',
        message: 'This is a primary alert',
      }, {
        id: 6,
        type: 'secondary',
        message: 'This is a secondary alert',
      });
  }
  log(log: string) {

  }
  ngOnInit() { }
}
