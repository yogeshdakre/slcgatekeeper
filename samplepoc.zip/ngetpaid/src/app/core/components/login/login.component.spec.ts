import { UserService } from '@core/services/user.service';
import { LoginComponent } from './login.component';
import { ChangeCurrentCompany } from './../../store/actions/company.actions';
import { async, fakeAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialogRef } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { Subject } from 'rxjs/Subject';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { NavigationService } from '@core/services/navigation.service';
import * as fromCore from '../../store';
import { select, Store } from '@ngrx/store';
import * as testUtil from '../../../../../testing';
import { Company } from '../../models/company';
import { MatFormFieldModule, MatSelectModule, MatInputModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';
import { Credential } from '@core/models/user';
import * as AuthActions from '../../store/actions/auth.actions';
/**
 * example of reactive form
 */
describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  //let store: { select: jasmine.Spy; dispatch: jasmine.Spy };
  let userService: { login: jasmine.Spy };
  let router: { navigate: jasmine.Spy };
  let store: { select: jasmine.Spy; dispatch: jasmine.Spy };
  let pending: Subject<boolean>;
  let loginBtn: HTMLButtonElement;
  beforeEach(
    async(() => {
      //navigationService = new NavigationService(null, null, null);
      store = jasmine.createSpyObj('Store', ['select', 'dispatch']);
      //dialogRef = jasmine.createSpyObj('MatDialogRef', ['close']);
      userService = jasmine.createSpyObj('UserService', ['login']);
      router = jasmine.createSpyObj('router', ['navigate']);
      //location.path.and.returnValue("");
      // private userService: UserService,
      //private router: Router,
      //  private fb: FormBuilder,
      // private language: LanguageService
      //
      //
      //
      TestBed.configureTestingModule({
        declarations: [LoginComponent, testUtil.TranslatePipeMock],
        imports: [
          RouterTestingModule,
          MatInputModule,
          ReactiveFormsModule,
          FormsModule,
          NoopAnimationsModule,
          MatFormFieldModule,
          MatSelectModule
        ],
        providers: [{ provide: UserService, useValue: userService }, { provide: Store, useValue: store }],
        // Tells the compiler not to error on unknown elements and attributes
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    pending = new Subject();
    store.select.and.callFake(args => {
      if (args === fromCore.getLoginPending) {
        return pending.asObservable();
      }
    });
    pending.next(false);
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    loginBtn = fixture.debugElement.query(By.css('.loginButton')).nativeElement;
  });
  it('login is pending those form should be disabled', () => {
    pending.next(true);
    expect(fixture.componentInstance.loginForm.disabled).toBeTruthy();
    pending.next(false);
    expect(fixture.componentInstance.loginForm.disabled).toBeFalsy();
  });
  it('should create', () => {
    //console.log(component);
    expect(component).toBeTruthy();
  });
  it('username is required', () => {
    expect(fixture.componentInstance.loginForm.get('username').invalid).toBeTruthy();
    fixture.componentInstance.loginForm.patchValue({ username: 'test' });
    expect(fixture.componentInstance.loginForm.get('username').invalid).toBeFalsy();
    //expect(fixture.componentInstance.loginForm.get('username').invalid).toBeFalsthy();
  });
  it('password is required', () => {
    expect(fixture.componentInstance.loginForm.get('password').invalid).toBeTruthy();
    fixture.componentInstance.loginForm.patchValue({ password: '1234' });
    expect(fixture.componentInstance.loginForm.get('password').invalid).toBeFalsy();
    //expect(fixture.componentInstance.loginForm.get('username').invalid).toBeFalsthy();
  });

  it('button is disabled', () => {
    expect(fixture.componentInstance.loginForm.get('password').invalid).toBeTruthy();
    expect(loginBtn.disabled).toBe(true);
    //fixture.componentInstance.loginForm.patchValue({ password: '1234' });
    //expect(fixture.componentInstance.loginForm.get('password').invalid).toBeFalsy();
    //expect(fixture.componentInstance.loginForm.get('username').invalid).toBeFalsthy();
  });
  it('button is enabled', () => {
    expect(fixture.componentInstance.loginForm.get('password').invalid).toBeTruthy();
    fixture.componentInstance.loginForm.patchValue({ username: 'get', password: '1234' });
    // we need angular to detect our changing.
    fixture.detectChanges();
    expect(loginBtn.disabled).toBe(false);
    //fixture.componentInstance.loginForm.patchValue({ password: '1234' });
    //expect(fixture.componentInstance.loginForm.get('password').invalid).toBeFalsy();
    //expect(fixture.componentInstance.loginForm.get('username').invalid).toBeFalsthy();
  });
  it('login', () => {
    //this.store.dispatch(new AuthActions.Login(value));
    const cred: Credential = { username: 'jimmy', password: '12345678' };
    fixture.componentInstance.login(cred);
    store.dispatch.and.callThrough();
    expect(store.dispatch).toHaveBeenCalledWith(new AuthActions.Login(cred));
  });
});
