import { Store } from '@ngrx/store';
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from '@core/services/user.service';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { LanguageService } from '@core/services/language.service';
import { patternValidator } from '../../pattern-validator';
import { Credential } from '../../models/user';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { catchError, map } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { switchMap, distinctUntilChanged, debounceTime, publish, exhaustMap, mergeMap } from 'rxjs/operators';
import { fromEvent } from 'rxjs/observable/fromEvent';
import * as fromCore from '../../store';
import * as AuthActions from '../../store/actions/auth.actions';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm: FormGroup;
  //private loginSubject = new Subject<Credential>();
  private sub: Subscription;
  constructor(
    private userService: UserService,
    private router: Router,
    private fb: FormBuilder,
    private store: Store<fromCore.State>
  ) {}
  ngOnDestroy() {
    //this.loginSubject.complete();
    this.sub.unsubscribe();
  }
  ngOnInit() {
    /* example of rx.js convert a cold to hot
    const obs = Observable
            .create(observer => observer.next(Date.now()));
    const connectObs = obs.pipe(publish());

    connectObs.subscribe(v => console.log("1st subscriber: " + v));
    connectObs.subscribe(v => console.log("2nd subscriber: " + v));
    connectObs.connect();*/
    // we need to unsubscribe this one.
    /*
    this.sub = this.language.languageChanged.subscribe(flag => {
      if (flag) {
        console.log(this.translate.instant('0xF0A2') + '(' + this.translate.instant('0x320A') + ')');
        //this.fisI18nService.translate('0xF0A2') + "(" + this.fisI18nService.translate('0x320A') + ")"
      }
    });*/
    this.createForm();
    this.sub = this.store.select(fromCore.getLoginPending).subscribe(pending => {
      if (pending) {
        this.loginForm.disable();
      } else {
        this.loginForm.enable();
      }
    });
    //this.loginSubject = fromEvent(this.button._elementRef.nativeElement, 'click');
    //this.clicks$.subscribe(test =>console.log(test))
    //this is something we need.
    /*this.loginSubject
      .pipe(
        debounceTime(50),
        // this is nice to have.
        distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)),
        exhaustMap(value => {
          console.log(value);
          const result: Credential = Object.assign({}, this.loginForm.value);
          return this.userService.login(result);
        })
      )
      .subscribe(result => {
        if (result) {
          this.router.navigate(['home']);
          console.log(result);
        }
      });*/
  }
  private createForm() {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, patternValidator(/^[a-zA-Z0-9_]*$/)]],
      password: ['', Validators.required]
    });
  }
  login(value: Credential) {
    //this.loginSubject.next(value);
    this.store.dispatch(new AuthActions.Login(value));
    /*const result = await this.userService.login(value);
    if (result) {
      this.router.navigate(["home"]);
      console.log(result);
    }*/
  }
  /*changeLang(lang: string) {
    this.userService.changeLang(lang);
  }*/
}
