import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { FormControl, NgModel } from "@angular/forms";
import { TranslateService } from "@ngx-translate/core";

export interface IdValue {
  id: string;
  value: string;
}

@Component({
  selector: "app-quick-search",
  templateUrl: "./quick-search.component.html",
  styleUrls: ["./quick-search.component.scss"]
})
export class QuickSearchComponent implements OnInit {
  public searchOptionGroupsControl: FormControl = new FormControl();
  public searchOptionsControl: FormControl = new FormControl();
  public searchCriteriaControl: FormControl = new FormControl();
  searchCriterias: IdValue[] = [
    { id: "starts", value: "0xF785" },
    { id: "contains", value: "0xF787" },
    { id: "ends", value: "0xF786" },
    { id: "equals", value: "0xF788" }
  ];

  searchOptionGroups: IdValue[] = [
    { id: "customer", value: "0xF0A5" },
    { id: "problems", value: "0xF31F" },
    { id: "ends", value: "0xF786" },
    { id: "equals", value: "0xF788" }
  ];

  searchOptions: IdValue[] = [
    { id: "findAllPkByCustomerName", value: "0xF0A2" },
    { id: "findAllPkByCustomerNo", value: "0xF00A" },
    { id: "findAllPkByActiveCustName", value: "0xF0A2" },
    { id: "findAllPkByActiveCustNo", value: "0xF00A" },
    { id: "findAllPkByInactiveCustName", value: "0xF733" },
    { id: "findAllPkByInactiveCustNo", value: "0xF732" },
    { id: "findAllPkByCustZip", value: "0x250A" }
  ];

  currentSearchOption: string;
  currentSearchOperator: string;
  searchValue: string;

  message = "Send message to parent..";

  @Output() messageEvent = new EventEmitter<string>();

  constructor(private translate: TranslateService) {}

  ngOnInit() {
    console.log("Init quick search");
    const self = this;

    /**
      this.searchGroups = [
        {
          name: '0xF0A5',
          children: [
            { value: 'findAllPkByCustomerName', viewValue: '0xF0A2' },
            { value: 'findAllPkByCustomerNo', viewValue: '0xF00A' },
            { value: 'findAllPkByActiveCustName', viewValue: '0xF0A2' },
            { value: 'findAllPkByActiveCustNo', viewValue: '0xF00A' },
            { value: 'findAllPkByInactiveCustName', viewValue: '0xF733' },
            { value: 'findAllPkByInactiveCustNo', viewValue: '0xF732' },
            { value: 'findAllPkByCustZip', viewValue: '0x250A' }
          ]
        },
        {
          name: '0xF31F',
          children: [
            { value: 'findAllPkByProblemId', viewValue: '0xF494' },
            { value: 'findAllPkByInvNo', viewValue: '0x00FF' },
            { value: 'findAllPkByCheckNum', viewValue: '0x0100' },
            { value: 'findAllPkByInvRef', viewValue: '0xF08D' },
            { value: 'findAllPkByInvPoNum', viewValue: '0xF0AC' },
            { value: 'findAllPkByCustNo', viewValue: '0xF00A' },
            { value: 'findAllPkByCustName', viewValue: '0xF0A2' },
            { value: 'findAllPkByGroup', viewValue: '0xEAA4' }
          ]
        },
        {
          name: '0x2701',
          children: [
            { value: 'findAllPkByContactName', viewValue: '0x48FC' },
            { value: 'findAllPkByPhone', viewValue: '0x004E' },
            { value: 'findAllPkByFax', viewValue: '0xF078' },
            { value: 'findAllPkByEmail', viewValue: '0x006A' },
            { value: 'findAllPkBySMS', viewValue: '0xE183' },
            { value: 'findAllPkByContZip', viewValue: '0x250A' }
          ]
        },
        {
          name: '0x9923',
          children: [
            { value: 'mew-9', viewValue: 'Mew' }, 
            { value: 'mewtwo-10', viewValue: 'Mewtwo' }
          ]
        },
        {
          name: 'GP_ADMIN_COMPANYSETUP_PAYMENT_INSTRUMENT',
          children: [
            { value: 'findAllPkByInstrNo', viewValue: 'GP_COLLECTION_PAYMENT_INSTR_INSTR_NO' },
            { value: 'findAllPkByType', viewValue: '0x9C03' },
            { value: 'findAllPkByCustNo', viewValue: '0xF00A' }           
          ]
        }
      ];
     */
    //      self.translate.get('0xF785').subscribe((res: string) => { console.log(res);  });
  }

  onEnter(value: string) {
    console.log(value);
  }

  sendMessage() {
    this.messageEvent.emit(this.message);
  }
}
