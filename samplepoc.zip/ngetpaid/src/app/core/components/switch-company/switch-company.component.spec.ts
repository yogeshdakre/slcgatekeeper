import { ChangeCurrentCompany } from './../../store/actions/company.actions';
import { async, fakeAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialogRef } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { SwitchCompanyComponent } from './switch-company.component';
import { NavigationService } from '@core/services/navigation.service';
import * as fromCore from '../../store';
import { select, Store } from '@ngrx/store';
import * as testUtil from '@testing/index';
import { Company } from '../../models/company';
import { MatFormFieldModule, MatSelectModule, MatInputModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

/**
 * example of reactive form
 */
describe('SwitchCompanyComponent', () => {
  let component: SwitchCompanyComponent;
  let fixture: ComponentFixture<SwitchCompanyComponent>;
  let store: { select: jasmine.Spy; dispatch: jasmine.Spy };
  let dialogRef: { close: jasmine.Spy };

  beforeEach(
    async(() => {
      //navigationService = new NavigationService(null, null, null);
      store = jasmine.createSpyObj('Store', ['select', 'dispatch']);
      dialogRef = jasmine.createSpyObj('MatDialogRef', ['close']);
      //location.path.and.returnValue("");
      TestBed.configureTestingModule({
        declarations: [SwitchCompanyComponent, testUtil.TranslatePipeMock],
        imports: [
          RouterTestingModule,
          MatInputModule,
          ReactiveFormsModule,
          FormsModule,
          NoopAnimationsModule,
          MatFormFieldModule,
          MatSelectModule
        ],
        providers: [{ provide: MatDialogRef, useValue: dialogRef }, { provide: Store, useValue: store }],
        // Tells the compiler not to error on unknown elements and attributes
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    const testCurrentCompany: Company = { companyId: 1, companyName: 'fis' };
    const testCompanyList: Company[] = [{ companyId: 1, companyName: 'fis' }, { companyId: 2, companyName: 'getpaid' }];
    store.select.and.callFake(args => {
      if (args === fromCore.selectCurrentCompany) {
        console.log('xxxx');
        return of(testCurrentCompany);
      } else {
        console.log('yyyy');
        return of(testCompanyList);
      }
    });
    fixture = TestBed.createComponent(SwitchCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    //console.log(component);
    expect(component).toBeTruthy();
  });
  describe('Select company changes', () => {
    let options: HTMLElement[];
    let selectMenu: testUtil.SelectTestHelper;

    beforeEach(() => {
      selectMenu = new testUtil.SelectTestHelper(fixture, 'companyList');
      //component.users = [{ id: randomId(), displayName: 'User1' }];
    });
    beforeEach(
      fakeAsync(() => {
        selectMenu.trigger();
        options = selectMenu.getOptions();
      })
    );

    afterEach(() => {
      selectMenu.cleanup();
    });
    it(
      'we should have fis and getpaid in companyList',
      fakeAsync(() => {
        expect(options.length).toBe(2);
        options.forEach((option: HTMLElement, index: number) => {
          selectMenu.selectOption(option);
          if (index === 0) {
            expect(option.innerText.trim()).toBe('fis');
            expect(fixture.componentInstance.switchCompanyForm.get('companyList').value).toBe(1);
          }
          if (index === 1) {
            expect(option.innerText.trim()).toBe('getpaid');
            expect(fixture.componentInstance.switchCompanyForm.get('companyList').value).toBe(2);
          }
        });
      })
    );
    it('get current company', () => {
      expect(fixture.componentInstance.switchCompanyForm.get('currentCompany').value).toBe('fis');
    });
    it(
      'change currentCompany',
      fakeAsync(() => {
        //console.log(component);
        //expect(component).toBeTruthy();
        //this.store.dispatch(new ChangeCurrentCompany(this.switchCompanyForm.get('companyList').value));
        //this.dialogRef.close('save');
        store.dispatch.and.callThrough();
        dialogRef.close.and.callThrough();
        selectMenu.selectOptionByKey(options, 'fis');
        fixture.componentInstance.saveCompany();
        expect(store.dispatch).toHaveBeenCalledWith(new ChangeCurrentCompany(1));
        expect(dialogRef.close).toHaveBeenCalledTimes(1);
      })
    );
  });
});
