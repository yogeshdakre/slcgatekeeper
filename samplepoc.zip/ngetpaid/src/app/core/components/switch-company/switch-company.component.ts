import { CompanyActionTypes, ChangeCurrentCompany } from '@core/store/actions/company.actions';
import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { UserService } from '@core/services/user.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromCore from '@core/store';
import { tap } from 'rxjs/operators';
import { Company } from '@core/models/company';

@Component({
  selector: 'app-switch-company',
  templateUrl: './switch-company.component.html',
  styleUrls: ['./switch-company.component.scss']
})
export class SwitchCompanyComponent implements OnInit {
  switchCompanyForm: FormGroup;
  currentCompany$: Observable<Company>;
  allCompanies$: Observable<Company[]>;

  constructor(
    public fb: FormBuilder,
    public dialogRef: MatDialogRef<SwitchCompanyComponent>,
    private store: Store<fromCore.State>
  ) {}

  ngOnInit() {
    this.currentCompany$ = this.store
      .select(fromCore.selectCurrentCompany)
      .pipe(tap(value => this.switchCompanyForm.patchValue({ currentCompany: value.companyName })));
    this.allCompanies$ = this.store.select(fromCore.selectAllCompany);

    this.switchCompanyForm = this.fb.group({
      currentCompany: [{ disabled: true }, []],
      companyList: ['', Validators.required]
    });
    //const allCompanies = this.userService.getUserData().allCompanies;
    /*this.companies = [];
    for (let i = 0; i < allCompanies.length; i++) {
      if (this.userService.getCurrentCompany().companyId !== allCompanies[i].companyId) {
        this.companies.push({
          id: allCompanies[i].companyId,
          name: allCompanies[i].companyName
        });
      }
    }*/

    //if (this.companies.length === 1) this.switchCompanyForm.patchValue({ companyList: this.companies[0].id });
  }

  saveCompany() {
    //const result = await this.userService.setCurrentCompany(this.switchCompanyForm.get('companyList').value);
    this.store.dispatch(new ChangeCurrentCompany(this.switchCompanyForm.get('companyList').value));
    this.dialogRef.close('save');
  }
}
