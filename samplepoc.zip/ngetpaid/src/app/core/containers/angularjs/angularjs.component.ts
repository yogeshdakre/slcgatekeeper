import { Component, OnInit, OnDestroy, ElementRef, ViewChild, Input } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie-service';
import { NavigationService } from '@core/services/navigation.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-angularjs',
  templateUrl: './angularjs.component.html',
  styleUrls: ['./angularjs.component.scss']
})
export class AngularjsComponent implements OnInit, OnDestroy {
  @ViewChild('iframe') iframe: ElementRef;
  subscriptions: Subscription[] = [];

  //@Input("outlet") outlet:  ElementRef;
  constructor(
    private router: Router,
    private sanitizer: DomSanitizer,
    private cookieService: CookieService,
    private navigationService: NavigationService
  ) {
    //this.subscriptions = new Array[2];
  }
  goto(id: string) {
    //console.log(this.outlet);
    //console.log("newruf id",id);
    this.iframe.nativeElement.contentWindow.postMessage({ navigateTo: '#' + id }, '*');
    if (id !== 'blank') {
      if (id.startsWith('col.customer.window')) {
        this.router.navigate(['col/n1Col', id]);
      } else {
        this.router.navigate(['n1', id]);
      }
    }
  }
  gotoWithMessage(id: string, message: Object) {
    this.iframe.nativeElement.contentWindow.postMessage(message, '*');
    if (id !== 'blank') {
      if (id.startsWith('col.customer.window')) {
        this.router.navigate(['col/n1Col', id]);
      } else {
        this.router.navigate(['n1', id]);
      }
    }
  }

  sendMessage(message: Object) {
    this.iframe.nativeElement.contentWindow.postMessage(message, '*');
  }
  ngOnDestroy() {
    this.subscriptions[0].unsubscribe();
    this.subscriptions[1].unsubscribe();
  }
  ngOnInit() {
    //console.log("newruf hash",location.hash);
    if (location.hash.startsWith('#/n1')) {
      this.goto(location.hash.substring(5));
    }
    // we need to unsubstribe this, because when user login and logout the component will be recreated.
    this.subscriptions.push(
      this.navigationService.getN1NextDestination().subscribe(next => {
        this.goto(next);
      })
    );
    this.subscriptions.push(
      this.navigationService.getN1CurrentNavigationNotifiction().subscribe(nav => {
        console.log(nav);
        if (!location.hash.includes('n1Col') && nav['nav'].startsWith('/col.customer.window')) {
          this.router.navigate(['col/n1Col', nav['nav']]);
        }
      })
    );
  }
}
