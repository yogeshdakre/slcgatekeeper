import { Component, Inject, OnInit, ViewChild, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UserService } from '@core/services/user.service';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { ConfigService } from '@core/services/config.service';
import { LanguageService } from '@core/services/language.service';
import { NavigationService } from '@core/services/navigation.service';
import { MatDialog, MatDialogRef, MatDialogConfig, MAT_DIALOG_DATA } from '@angular/material';
import { SwitchCompanyComponent } from '../components/switch-company/switch-company.component';
import { AngularjsComponent } from './angularjs/angularjs.component';
import { Company } from '../models/company';
import { select, Store } from '@ngrx/store';
import * as fromCore from '../store';

import * as CompanyActions from '../store/actions/company.actions';
import * as AuthActions from '../store/actions/auth.actions';
import * as NavActions from '../store/actions/nav.actions';

const defaultDialogConfig = new MatDialogConfig();

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  dialogRef: MatDialogRef<SwitchCompanyComponent> | null;

  @ViewChild('angularjs') angularjs: AngularjsComponent;

  //company: Company;
  currentCompany$: Observable<Company>;

  adminLabel: string;
  isAdmin$: Observable<boolean>;
  isMenuOpen: boolean;
  isLoggedIn$: Observable<boolean>;
  showN1$: Observable<boolean>;
  menuData$: Observable<any>;
  message: string;
  config = {
    disableClose: false,
    panelClass: 'custom-overlay-pane-class',
    hasBackdrop: true,
    backdropClass: '',
    width: '400',
    height: '300'
  };
  utility = [
    {
      icon: 'fis-icon-email',
      label: 'Inbox (17)',
      path: 'iframe',
      url: 'http://www.ibm.com',
      children: []
    }
  ];

  constructor(
    private router: Router,
    public userService: UserService,
    translate: TranslateService,
    private languageService: LanguageService,
    private navigationService: NavigationService,
    public dialog: MatDialog,
    private store: Store<fromCore.State>
  ) {
    //this.currentCompany$ = this.store.pipe(select(fromCore.getCurrentCompany));
  }

  @HostListener('window:message', ['$event'])
  onMessage(event) {
    if (!this.angularjs) {
      return;
    }
    // 1. For jsp page -> navigate to classic shell.  the new shell will just pass by those message into classic.
    // 2. for classic shell navigation, the new shell will capture the message and do some special handling if need.
    //    having shellNotification flag.
    // 3. if the struts jsp is open within the old shell, the new shell won't capture any message.
    // 4. for new message, we need to have a specialy flag, shellDestination: n1: angularjs, lc: old struts.
    if (event.data['shellNotification']) {
      this.navigationService.notifyN1CurrentNavigation(event.data);
    } else if (event.data['shellDestination']) {
      if (event.data['shellDestination'] === 'lc') {
        //this.n
        //so this is only for customer window.
        if (event.data['nav'] === 'followUpCount') {
          //getpaid/zeroclient/VFSFollowupDrilldownList.do
          this.navigationService.navigateTo(['lc', '/getpaid/zeroclient/VFSFollowupDrilldownList.do']);
        }
      }
    } else if (event.data['legacyCustomerList']) {
      this.store.dispatch(new NavActions.ShowAngularJS());
      this.angularjs.gotoWithMessage(event.data['legacyCustomerList'], event.data);
    } else {
      this.angularjs.sendMessage(event.data);
    }
    /*
       //The above condition hardcode we will change the post message to make this change consistent
      if(event.data["newruf_angularjs"]){
        //this.router.navigate(["n1", $event.id]);
        this.navigationService.navigateToAngularjs();
      }else{
          this.navigationService.navigateToOther();
          this.router.navigate(["lc", event.data["newruf_id"]]);
      }
      this.angularjs.gotoWithMessage(event.data["newruf_id"],event.data);
    }else{
      //Pass on all the messages to the ANGULARJS ruf classic....
      this.angularjs.sendMessage(event.data);*/
  }
  ngOnInit() {
    /** It’s a common practice to use ngOnInit to perform initialization logic even if this logic doesn’t depend on DI, DOM or input bindings. */
    this.isLoggedIn$ = this.store.select(fromCore.getLoggedIn);
    this.showN1$ = this.store.select(fromCore.getShowAngularJS);
    this.isAdmin$ = this.store.select(fromCore.getAdmin);
    this.currentCompany$ = this.store.select(fromCore.selectCurrentCompany);
    this.menuData$ = this.store.select(fromCore.getMenu);
    this.store.select(fromCore.getLoggedIn).subscribe(logined => {
      if (logined) {
        //console.log('dispatch');
        //this is really http client to close the subscription.
      } else {
        this.router.navigate(['login']);
      }
    });
    this.userService.getLang().subscribe(lang => {
      this.languageService.changeLanguage(lang.toString());
    });

    //this.company = this.userService.getCurrentCompany();
    // :TODO
    // this should be call when user is login, it's possible the data is empty at that time, it's only available when user login.
    //this.nbrOfCompanies = this.userService.getUserData().allCompanies.length;
  }
  onActivate($event) {
    //console.log($event);
  }
  doMenuEvent(name: string) {
    console.log('doMenuEvent [' + name + ']');
  }
  logout() {
    this.store.dispatch(new AuthActions.Logout());
  }

  switchCompany() {
    const dialogRef = this.dialog.open(SwitchCompanyComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'save') {
        //this.company = this.userService.getCurrentCompany();
        this.router.navigate(['home']);
      }
    });
  }

  viewUserPreference() {
    this.navigationService.navigateTo(['lc', '/getpaid/zeroclient/userPreference.do']);
  }

  viewUserProfile() {
    this.navigationService.navigateTo(['lc', 'userFullName/userProfile']);
  }

  viewHelp() {
    console.log('help..');
  }

  switchToAdmin(viewAdmin: boolean) {
    ///this.isAdmin = viewAdmin;
    if (viewAdmin) {
      this.navigationService.load(true).subscribe(() => {
        // we should navigate to lc view not angularjs
        //this.oldmenuData = this.navigationService.getNavigation();
        this.store.dispatch(new NavActions.ShowAdmin());
        this.navigationService.navigateToN1('adminWelcome');
      });
    } else {
      this.navigationService.load(false).subscribe(() => {
        // we should navigate to lc view not angularjs
        //this.oldmenuData = this.navigationService.getNavigation();
        this.store.dispatch(new NavActions.ShowClient());
        this.navigationService.navigateToN1('welcome');
      });
    }
  }

  receiveMessage($event) {
    this.message = $event;
    console.log($event);
  }

  open($event) {
    console.log($event.url);
    //console.log(console.log(this.angularjs));
    this.isMenuOpen = false;
    if ($event.path === 'iframe') {
      if ($event.url) {
        this.navigationService.navigateTo(['lc', $event.url]);
      } else {
        this.navigationService.navigateToN1($event.id);
        //this.searchParent($event.id);
      }
    } else {
      this.navigationService.navigateTo([$event.path]);
    }
  }

  searchParent(child: String) {}
}
