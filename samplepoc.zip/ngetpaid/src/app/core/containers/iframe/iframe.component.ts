import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-iframe',
  templateUrl: './iframe.component.html',
  styleUrls: ['./iframe.component.scss']
})
export class IframeComponent implements OnInit {
  public src: SafeUrl;
  constructor(private route: ActivatedRoute, private sanitizer: DomSanitizer, private cookieService: CookieService) {}

  ngOnInit() {
    /*
    When subscribing to an observable in a component, you almost always arrange to unsubscribe when the component is destroyed.
    There are a few exceptional observables where this is not necessary. The ActivatedRoute observables are among the exceptions.
    The ActivatedRoute and its observables are insulated from the Router itself. The Router destroys a routed component when it is
     no longer needed and the injected ActivatedRoute dies with it.
    */

    /**
     * Two older properties are still available. They are less capable than their replacements, discouraged, and may be deprecated in a future Angular version.

        params - An Observable that contains the required and optional parameters specific to the route. Use paramMap instead.

       queryParams - An Observable that contains the query parameters available to all routes. Use queryParamMap instead.
     */

    this.route.paramMap.subscribe((params: ParamMap) => {
      const token = this.cookieService.get('XSRF-TOKEN');
      if (params.get('url').includes('?')) {
        this.src = this.sanitizer.bypassSecurityTrustResourceUrl(params.get('url') + '&csrfToken=' + token);
      } else {
        this.src = this.sanitizer.bypassSecurityTrustResourceUrl(params.get('url') + '?csrfToken=' + token);
      }
    });
  }
}
