import { Store } from '@ngrx/store';
import { Component, OnInit, HostBinding, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import * as fromCore from '@core/store';
import { NavigationService } from '@core/services/navigation.service';

@Component({
  selector: 'app-landing',
  template: `<div fxLayout="column" fxFlex="grow"><router-outlet (activate)="onActivate($event)" ></router-outlet></div>`,
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit, OnDestroy {
  @HostBinding('style.display') display = 'flex';
  subscription: Subscription;
  constructor(private store: Store<fromCore.State>) {}
  onActivate($event) {
    //console.log($event);
  }
  ngOnInit() {
    this.subscription = this.store.select(fromCore.getShowAngularJS).subscribe(showAngularjs => {
      if (showAngularjs) {
        this.display = 'none';
      } else {
        this.display = 'flex';
      }
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
