import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IframeComponent } from './containers/iframe/iframe.component';
import { LandingComponent } from './containers/landing/landing.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { GriddemoComponent } from './components/griddemo/griddemo.component';
import { AuthGuard } from './services/auth.guard';

const routes: Routes = [
  {
    path: '',
    canActivateChild: [AuthGuard],
    component: LandingComponent,
    children: [
      {
        path: 'lc/:url',
        component: IframeComponent
        //data: { expectedRole: ['GA_ADMIN', 'GP_COLLECTOR'] }
      },
      {
        path: 'n1/:url',
        component: HomeComponent
        //data: { expectedRole: ['GA_ADMIN', 'GP_COLLECTOR'] }
      },
      {
        path: 'home',
        component: HomeComponent
        //data: { expectedRole: 'GA_ADMIN' }
      },
      {
        path: 'griddemo',
        component: GriddemoComponent
        //data: { expectedRole: ['GA_ADMIN', 'GP_COLLECTOR'] }
      }
    ]
  },
  { path: 'login', component: LoginComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoreRoutingModule {}
