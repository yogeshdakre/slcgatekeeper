import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Optional, SkipSelf } from '@angular/core';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { CommonModule } from '@angular/common';
import { IframeComponent } from './containers/iframe/iframe.component';
import { AngularjsComponent } from './containers/angularjs/angularjs.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CoreRoutingModule } from './core-routing.module';
import { AuthGuard } from './services/auth.guard';
import { UserService } from './services/user.service';
import { LanguageService } from './services/language.service';
import { NavigationService } from './services/navigation.service';
import { LoginComponent } from './components/login/login.component';
import { SharedModule } from '../shared/shared.module';
import { JwtModule } from '@auth0/angular-jwt';
import { HomeComponent } from './components/home/home.component';
import { QuickSearchComponent } from './components/quick-search/quick-search.component';
import { TranslateModule, TranslateLoader, TranslatePipe } from '@ngx-translate/core';
import { ShellModule } from '@ruf/shell';
import { SwitchCompanyComponent } from './components/switch-company/switch-company.component';
import { LandingComponent } from './containers/landing/landing.component';
import { JwtService } from './services/jwt.service';
import * as reducers from './store';
import { CompanyEffects } from './store/effects/company.effects';
import { AuthEffects } from './store/effects/auth.effects';
import { NavEffects } from './store/effects/nav.effects';
import { AppComponent } from './containers/app.component';
import { GriddemoComponent } from './components/griddemo/griddemo.component';
import { AgGridModule } from 'ag-grid-angular';
import { httpInterceptorProviders } from './http-interceptors';

//import { ConnectFormDirective } from './connectForm.directive';
export function tokenGetter() {
  return localStorage.getItem('token');
}
@NgModule({
  imports: [
    CommonModule,
    CoreRoutingModule,
    SharedModule,
    ShellModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    TranslateModule,
    /**
     * StoreModule.forFeature is used for composing state
     * from feature modules. These modules can be loaded
     * eagerly or lazily and will be dynamically added to
     * the existing state.
     */
    StoreModule.forFeature('core', reducers.reducers),
    /**
     * Effects.forFeature is used to register effects
     * from feature modules. Effects can be loaded
     * eagerly or lazily and will be started immediately.
     *
     * All Effects will only be instantiated once regardless of
     * whether they are registered once or multiple times.
     */
    //autheffects must be end
    EffectsModule.forFeature([CompanyEffects, NavEffects, AuthEffects]),
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        blacklistedRoutes: ['/getpaid/login_action']
      }
    }),
    AgGridModule.withComponents([])
  ],
  entryComponents: [SwitchCompanyComponent],
  declarations: [
    IframeComponent,
    AngularjsComponent,
    LoginComponent,
    AppComponent,
    HomeComponent,
    QuickSearchComponent,
    SwitchCompanyComponent,
    LandingComponent,
    GriddemoComponent
  ],
  exports: [QuickSearchComponent, SwitchCompanyComponent, AngularjsComponent, LandingComponent, AppComponent],
  providers: [AuthGuard, UserService, LanguageService, NavigationService, JwtService, httpInterceptorProviders],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CoreModule {
  /* make sure CoreModule is imported only by one NgModule the AppModule */
  constructor(
    @Optional()
    @SkipSelf()
    parentModule: CoreModule
  ) {
    if (parentModule) {
      throw new Error('CoreModule is already loaded. Import only in AppModule');
    }
  }
}
