import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators';
import { DumpService } from '@testing/dump.service';
import * as AuthActions from '@core/store/actions/auth.actions';
import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './auth.interceptor';
import { Store } from '@ngrx/store';

describe(`AuthHttpInterceptor`, () => {
  let service: DumpService;
  let httpMock: HttpTestingController;
  let store: { dispatch: jasmine.Spy };
  beforeEach(() => {
    store = jasmine.createSpyObj('Store', ['dispatch']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        DumpService,
        {
          provide: HTTP_INTERCEPTORS,
          useClass: AuthInterceptor,
          multi: true
        },
        { provide: Store, useValue: store }
      ]
    });

    service = TestBed.get(DumpService);
    console.log(service);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should throw an exception when return 403 and dispatch loginRedirect action', () => {
    console.log(service);
    service
      .getRequset()
      .pipe(catchError(() => of('')))
      .subscribe(() => {});
    store.dispatch.and.callThrough();
    const httpRequest = httpMock.expectOne(`${service.ROOT_URL}/gets`).error(new ErrorEvent(''), { status: 403 });
    expect(store.dispatch(new AuthActions.LoginRedirect()));
    //expect(httpRequest.request.headers.has('Authorization'));
  });
});
