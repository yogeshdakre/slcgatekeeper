import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { catchError } from 'rxjs/operators';
import * as AuthActions from '@core/store/actions/auth.actions';
import * as fromCore from '@core/store/';
@Injectable()
export class AuthInterceptor {
  constructor(private store: Store<fromCore.State>) {}
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((response: any) => {
        if (response instanceof HttpErrorResponse && response.status === 401) {
          localStorage.removeItem('token');
          this.store.dispatch(new AuthActions.LoginRedirect());
          //this.router.navigateByUrl('/log-in');
        }
        return ErrorObservable.create(response);
      })
    );
  }
}
