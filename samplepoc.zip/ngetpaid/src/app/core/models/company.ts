export class Company {
  companyId: number;
  companyName: string;
  currencyCode?: string;
  defaultCompany?: boolean;
  forceProblemToGroup?: boolean;
  holidayList?: string[];
  pmOwnerLoad?: boolean;
  validWorkDays?: string;
}
