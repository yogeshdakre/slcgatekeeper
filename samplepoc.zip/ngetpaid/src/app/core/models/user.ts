export class User {
  id: number;
  email: string;
  namedUser: string;
  fullName: string;
  timezone: string;
  activeOwner: boolean;
  fax: string;
  active: boolean;

  //token?: string;
}
export class Credential {
  constructor(public username: string, public password: string) {}
}
