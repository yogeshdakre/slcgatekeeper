import * as AuthActions from '@core/store/actions/auth.actions';
import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UserService } from './user.service';
import { isArray } from 'util';
import { Store } from '@ngrx/store';
import * as fromCore from '@core/store';
/**
 * we don't need to use observable for authGuard.
 */
@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(public userService: UserService, public router: Router, public store: Store<fromCore.State>) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    console.log("dddddddddddddddddddddddddddddddddddddddd");
    console.log(ActivatedRouteSnapshot);
    return true;
  }
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    const expectedRole = next.data.expectedRole;
    console.log("dddddddddddddddddddddddddddddddddddddddd");
    console.log(ActivatedRouteSnapshot);
    return this.store.select(fromCore.getLoggedIn).map(authed => {
      if (!authed) {
        this.store.dispatch(new AuthActions.LoginRedirect());
        return false;
      } else {
        if (expectedRole) {
          if (expectedRole instanceof Array) {
            return this.userService.isUserInRoles(expectedRole);
          } else {
            return this.userService.isUserInRole(expectedRole);
          }
        }
        return true;
      }
    });
  }
}
