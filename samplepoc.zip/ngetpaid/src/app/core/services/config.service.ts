import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
@Injectable()
export class ConfigService {
  private _configObject: any = {};
  constructor(private http: HttpClient) {}
  getconfig() {
    return this._configObject;
  }
  load() {
    let confendpoint = "/getpaid/api/confignew.js";
    let myParam = location.search.split("solutionInstanceGuid=")[1];

    if (myParam === undefined || myParam == null) {
      const paramList = location.href.split("solutionInstanceGuid=");
      if (paramList.length > 1) {
        myParam = paramList[1].split("&")[0];
      }
    }
    if (myParam && myParam.length >= 1) {
      console.log("config will be loaded...with solutionGuid");
      confendpoint =
        "/getpaid/api/confignew.js?solutionInstanceGuid=" + myParam;
    }

    this.http.get(confendpoint).subscribe(config => {
      this._configObject = config;
    });
  }

  getconfigvalue(key: string) {
    return this._configObject[key];
  }
}
