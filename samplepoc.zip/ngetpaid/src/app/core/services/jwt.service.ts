import { Injectable } from '@angular/core';
import * as jwt_decode from "jwt-decode";

@Injectable()
export class JwtService {
  constructor() {}
  /* istanbul ignore next */
  jwtDecode(token: string): any {
    return jwt_decode(token);
  }
}
