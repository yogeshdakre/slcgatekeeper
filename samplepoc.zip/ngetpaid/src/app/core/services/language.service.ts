import { Injectable } from "@angular/core";
import {
  TranslateService,
  TranslationChangeEvent,
  LangChangeEvent
} from "@ngx-translate/core";
import { Observable } from "rxjs/Observable";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
@Injectable()
export class LanguageService {
  private _supportedLanguage: any = {
    en: "en-US",
    fr: "fr-FR",
    de: "de-DE",
    nl: "nl-NL",
    pt: "pt-PT",
    pl: "pl-PL",
    es: "es-ES",
    it: "it-IT",
    zh: "zh-ZH",
    ja: "ja-JP"
  };
  private useInstant: boolean;
  languageChanged = new BehaviorSubject<boolean>(true);
  constructor(private translate: TranslateService) {
    translate.setDefaultLang("en");
    translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.languageChanged.next(true);
    });
  }
  useBrowserLanguage() {
    console.log("using browser language", this.translate.getBrowserLang());
    this.translate.use(this.translate.getBrowserLang());
  }
  changeLanguage(lang: string) {
    this.languageChanged.next(false);
    let defaultlang = "en-US";
    if (lang) {
      lang = lang.substring(0, 2);
      lang = this._supportedLanguage[lang.toString()];
      if (lang) {
        defaultlang = lang.toString();
      }
    }
    this.translate.use(defaultlang);
  }
  getSupporteLanguage() {
    return this._supportedLanguage;
  }
}
