import { NavigationService } from './navigation.service';
import { JwtHelperService } from '@auth0/angular-jwt';
import { TranslateService } from '@ngx-translate/core';
import * as NavActions from '@core/store/actions/nav.actions';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
//import { asyncData, asyncError } from '../../../testing/async-observable-helpers';
import { of } from 'rxjs/observable/of';
import { AuthActionTypes } from '@core/store/actions/auth.actions';
/**
 *  we don't need testBed for service,
 *  this is like testing java unit testing,
 *  you mock dependence only if needed,
 * then create those pojo, and test it.
 */
describe('NavigationService', () => {
  const clientJson = {
    main: [
      {
        label: 'HOME',
        title: 'HOME',
        icon: 'glyphicon glyphicon-home fis-i-home',
        id: 'welcome',
        partial: 'views/framed-in.html',
        closeable: true,
        args: {
          url: '/getpaid/zeroclient/home.do'
        },
        children: [
          {
            label: 'WELCOME',
            title: 'WELCOME',
            id: 'welcomeHome',
            path: 'home'
          }
        ]
      },
      {
        label: 'Collection',
        id: 'col.colActivity',
        title: 'Collection',
        role: 'GP_COLLECTOR',
        children: [
          {
            label: "i18n('0x1F08')",
            title: "i18n('0x1F08')",
            id: 'col.summary',
            partial: 'views/framed-in.html',

            args: {
              url: '/getpaid/zeroclient/FollowUpSummary.do'
            }
          },
          {
            label: 'Who to contact',
            title: 'Who to contact',
            id: 'col.whoToContactNew',
            role: 'GP_COLLECTOR',
            template: '<who-to-contact/>'
          }
        ]
      }
    ]
  };

  let service: NavigationService;
  let httpClientSpy: { get: jasmine.Spy };
  let jwtHelperService: JwtHelperService;
  let routerSpy: { get: jasmine.Spy };
  let location: { path: jasmine.Spy };
  let store: { dispatch: jasmine.Spy };
  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    location = jasmine.createSpyObj('Location', ['path']);
    store = jasmine.createSpyObj('Store', ['dispatch']);
    // let set it default is n1.
    jwtHelperService = new JwtHelperService();
    service = new NavigationService(<any>httpClientSpy, <any>routerSpy, <any>store);
  });

  it('load menu', () => {
    httpClientSpy.get.and.returnValue(of(clientJson));

    service.load().subscribe(value => {
      expect(value.length).toBe(2);
      expect(value[0]['label']).toBe('HOME');
      expect(value[0]['children'].length).toBe(1);
      //console.log(value[0]);
    });
  });

  it('navigateToN1 to and get notification from n1nextDestination', () => {
    let n1next = '';
    store.dispatch.and.callThrough();
    //because of N1NextDestination isn't relaySubject, we need to subscribe it before it happening.
    service.getN1NextDestination().subscribe(result => {
      n1next = result;
    });
    service.navigateToN1('customerWindow');
    expect(store.dispatch).toHaveBeenCalledWith(new NavActions.ShowAngularJS());
    expect(n1next).toBe('customerWindow');
  });
  it('navigateTo others to and get blank notification from n1nextDestination', () => {
    let n1next = '';
    store.dispatch.and.callThrough();

    //because of N1NextDestination isn't relaySubject, we need to subscribe it before it happening.
    service.getN1NextDestination().subscribe(result => {
      n1next = result;
    });
    service.navigateTo([]);
    expect(store.dispatch).toHaveBeenCalledWith(new NavActions.HideAngularJS());
    expect(n1next).toBe('blank');
  });
  it('getN1CurrentNavigation', () => {
    let currentNav;
    service.getN1CurrentNavigationNotifiction().subscribe(result => {
      currentNav = result;
    });
    service.notifyN1CurrentNavigation('newPath');

    expect(currentNav).toBe('newPath');
  });
});
