import * as NavActions from '@core/store/actions/nav.actions';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ParamMap } from '@angular/router';
import { Location } from '@angular/common';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { publishReplay, refCount } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import * as fromCore from '@core/store';
@Injectable()
export class NavigationService {
  // the next destination of angular.js app.
  private n1NextDestination = new Subject<string>();
  private n1CurrentNavigationNotifiction = new Subject<string>();
  // the subject for if angular.js app is showing or not
  //isShowN1 = new BehaviorSubject<boolean>(this._initalShowAngularjs());
  constructor(private http: HttpClient, private router: Router, private store: Store<fromCore.State>) {}

  /*_initalShowAngularjs() {
    if(this.location && this.location.path()){
      return this.location.path().startsWith("/n1");
    }else{
      return false;
    }
    
  }*/
  // it return observable object for next navigation target.
  getN1NextDestination(): Observable<any> {
    return this.n1NextDestination.asObservable();
  }
  notifyN1CurrentNavigation(message: string) {
    this.n1CurrentNavigationNotifiction.next(message);
  }
  getN1CurrentNavigationNotifiction() {
    return this.n1CurrentNavigationNotifiction.asObservable();
  }
  navigateToN1(whereToGo: string) {
    this.store.dispatch(new NavActions.ShowAngularJS());
    this.n1NextDestination.next(whereToGo);
  }
  navigateTo(commands: any[]) {
    this.store.dispatch(new NavActions.HideAngularJS());
    this.router.navigate(commands);
    this.n1NextDestination.next('blank');
  }

  //show angularjs iframe
  //showN1() {
  // this.isShowN1.next(true);
  //}
  //hide angularjs iframe
  //hideN1() {
  //  this.isShowN1.next(false);
  //}
  //isN1(): Observable<boolean> {
  // return this.isShowN1
  //  .asObservable().pipe(publishReplay(1),refCount());
  // }

  load(admin: Boolean = false): Observable<Array<any>> {
    let navigationendpoint = '/getpaid/api/navigation.json';
    if (admin) {
      navigationendpoint = navigationendpoint + '?loadAdmin=true';
    }
    return this.http.get(navigationendpoint).map(navigation => {
      const adapter: Array<any> = [];
      const mainobject: Array<any> = navigation['main'];
      mainobject.map((singleobj, index) => {
        const whattoadd3 = { label: singleobj['label'], path: 'iframe' };
        const whattoadd2 = {
          label: singleobj['label'],
          path: 'iframe',
          id: singleobj['id']
        };
        if (singleobj['children']) {
          whattoadd3['children'] = [];
          whattoadd2['children'] = [whattoadd3];
          singleobj['children'].map((cobj, index2) => {
            const childrentoadd = { label: cobj['label'], path: 'iframe' };
            //this is old struts or angularjs
            if (cobj['args']) {
              childrentoadd['url'] = cobj['args']['url'];
            } else {
              if (cobj['path']) {
                childrentoadd['path'] = cobj['path'];
              }
            }
            childrentoadd['id'] = whattoadd2['id'] + '/' + cobj['id'];
            whattoadd3['children'].push(childrentoadd);
          });
        } else {
        }
        adapter.push(whattoadd2);
      });

      // let megamenu = adapter
      //console.log("adapter", JSON.stringify(adapter));
      return adapter;
    });
  }
}
