import { UserService } from './user.service';
import { JwtService } from './jwt.service';
import { of } from 'rxjs/observable/of';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { HttpErrorResponse } from '@angular/common/http';
import { JwtHelperService } from '@auth0/angular-jwt';
import { TranslateService } from '@ngx-translate/core';
import { Credential } from '../models/user';

describe('UserService', () => {
  let service: UserService;
  let httpClientSpy: { get: jasmine.Spy; post: jasmine.Spy; put: jasmine.Spy };
  let jwtHelperService: { tokenGetter: jasmine.Spy; isTokenExpired: jasmine.Spy };
  let translateService: TranslateService;
  let jwtService: { jwtDecode: jasmine.Spy };
  beforeEach(() => {
    //let us setup
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'put']);

    jwtHelperService = jasmine.createSpyObj('JwtHelperService', ['tokenGetter', 'isTokenExpired']);
    translateService = jasmine.createSpyObj('UserService', ['getBrowserLang']);
    jwtService = jasmine.createSpyObj('JwtService', ['jwtDecode']);
    localStorage.clear();
    service = new UserService(<any>jwtHelperService, <any>httpClientSpy, translateService, jwtService);
  });
  it('_isAuthenticated return false', () => {
    jwtHelperService.tokenGetter.and.returnValue('token');
    jwtHelperService.isTokenExpired.and.returnValue(false);
    expect(service.checkAutentication()).toBe(true);
  });
  it('_isAuthenticated return null', () => {
    jwtHelperService.tokenGetter.and.returnValue(null);
    //jwtHelperService.isTokenExpired.and.returnValue(false);
    expect(service.checkAutentication()).toBe(false);
  });

  it('_isAuthenticated return true when logined', () => {
    jwtHelperService.tokenGetter.and.returnValue('token');
    jwtHelperService.isTokenExpired.and.returnValue(true);

    expect(service.checkAutentication()).toBe(false);
  });

  it('_isAuthenticated return false when exception', () => {
    jwtHelperService.tokenGetter.and.throwError('');
    jwtHelperService.isTokenExpired.and.returnValue(true);

    expect(service.checkAutentication()).toBe(false);
  });

  it('is collector in isUserInRole', () => {
    jwtService.jwtDecode.and.returnValue({ roles: ['collector'] });
    expect(service.isUserInRole('collector')).toBe(true);
    //const jwtDecode = spyOn(service, 'jwtDecode');
  });

  it('is collector in isUserInRoles', () => {
    jwtService.jwtDecode.and.returnValue({ roles: ['collector', 'casher'] });
    expect(service.isUserInRoles(['collector'])).toBe(true);
    //const jwtDecode = spyOn(service, 'jwtDecode');
  });

  it('changeLang to chinese', () => {
    service.changeLang('chinese');
    let lang = 'english';
    service.getLang().subscribe(result => {
      lang = result;
    });
    expect(lang).toBe('chinese');
  });
  it('login successfully', () => {
    httpClientSpy.post.and.returnValue(of({ jwtToken: 'fakeToken', userName: 'getpaid' }));
    //remember this is a code observable we need to subscribe it.
    service.login(new Credential('get', '12345678')).subscribe(result => {
      expect(result).toBe(true);
    });
  });
  it('login with exceptions', () => {
    const errorResponse = new HttpErrorResponse({
      error: 'test 403 error',
      status: 403,
      statusText: 'Failed'
    });
    httpClientSpy.post.and.returnValue(ErrorObservable.create(errorResponse));
    //remember this is a code observable we need to subscribe it.
    service.login(new Credential('get', '12345678')).subscribe(result => {
      expect(result).toBe(false);
    });
  });

  it('logout', () => {
    httpClientSpy.get.and.returnValue(of({}));
    service.logout();
    expect(localStorage.getItem('token')).toBeNull();
    expect(localStorage.getItem('getpaid_userData')).toBeNull();
  });

  it('setCurrentCompany with successful ', () => {
    httpClientSpy.put.and.returnValue(of({}));
    localStorage.setItem('getpaid_userData', JSON.stringify({ companyId: 1, companyLabel: '111' }));
    service.setCurrentCompany(1).subscribe(() => {});

    expect(service.getCurrentCompany().companyId).toBe(1);
  });

  it('setCurrentCompany with failure ', () => {
    const errorResponse = new HttpErrorResponse({ error: 'test 403 error', status: 403, statusText: 'Failed' });
    localStorage.setItem('getpaid_userData', JSON.stringify({ companyId: 2, companyLabel: '222' }));

    httpClientSpy.put.and.returnValue(ErrorObservable.create(errorResponse));
    service.setCurrentCompany(1);
    expect(service.getCurrentCompany().companyId).toBe(2);
  });
});
