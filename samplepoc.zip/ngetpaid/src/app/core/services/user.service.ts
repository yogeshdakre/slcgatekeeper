import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { map, catchError, refCount, publishReplay, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

import { Credential } from '@core/models/user';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
//import * as jwt_decode from "jwt-decode";
import { JwtService } from './jwt.service';
import { TranslateService } from '@ngx-translate/core';
import { Company } from '@core/models/company';

@Injectable()
export class UserService {
  constructor(
    public jwtHelper: JwtHelperService,
    private http: HttpClient,
    private translate: TranslateService,
    private jwtService: JwtService
  ) {}
  //isLoginSubject = new BehaviorSubject<boolean>(this._isAuthenticated());
  langSubject = new BehaviorSubject<string>(this._getLang());
  private url = '/getpaid/login_action';
  checkAutentication(): boolean {
    const result = this._isAuthenticated();
    //this.isLoginSubject.next(result);
    return result;
  }
  _isAuthenticated(): boolean {
    //return true;
    // Check whether the token is expired and return
    // true or false
    try {
      if (this.jwtHelper.tokenGetter() != null) {
        if (this.jwtHelper.isTokenExpired()) {
          return false;
        }
        return true;
      } else {
        //console.log("return false");
        return false;
      }
    } catch (ex) {
      console.log(ex);
      return false;
    }
  }

  isUserInRole(role: string): boolean {
    const token = this.jwtHelper.tokenGetter();
    const tokenPayload = this.jwtService.jwtDecode(token);
    return tokenPayload.roles.includes(role);
  }

  isUserInRoles(roles: string[]): boolean {
    const token = this.jwtHelper.tokenGetter();
    const tokenPayload = this.jwtService.jwtDecode(token);
    const found = roles.some(r => tokenPayload.roles.includes(r));
    return found;
  }

  /* isLoggedIn(): Observable<boolean> {
    // use .share() when creating the isLoginSubject Observable, so that your async pipes don’t create multiple subscriptions.
    //https://medium.com/@mikesnare/angular-async-pipes-beware-the-share-bcc9c1cd849d
    //https://stackoverflow.com/questions/42825763/behaviorsubject-initial-value-not-working-with-share/42827023
    return this.isLoginSubject.asObservable().pipe(publishReplay(1), refCount());
  }*/
  getLang(): Observable<string> {
    return this.langSubject.asObservable().pipe(publishReplay(1), refCount());
  }
  changeLang(lang: string) {
    this.langSubject.next(lang);
  }
  login(credential: Credential): Observable<boolean> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    headers.set('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8');
    return this.http
      .post(this.url, { j_username: credential.username, j_password: credential.password }, { headers: headers })
      .pipe(
        map((res: Object) => {
          //console.log("!!!!!!"+res);
          localStorage.setItem('getpaid_userData', JSON.stringify(res));
          localStorage.setItem('token', JSON.stringify(res['jwtToken']));
          this.langSubject.next(this._getLang());
          //this.isLoginSubject.next(true);
          return true;
        }),
        catchError(() => of(false))
      );
    /*
    } catch (error) {
      this.isLoginSubject.next(false);
      //this.langSubject.next(this._getLang());

      console.log(error);
      return false;
    }*/
  }
  getUserData() {
    const userData = localStorage.getItem('getpaid_userData');
    return userData ? JSON.parse(userData) : '';
  }

  setCurrentCompany(companyId: number): Observable<any> {
    console.log('set default company to [' + companyId + ']');
    return this.http.put('/getpaid/api/company/' + companyId, {}).pipe(
      tap(() => {
        //localStorage.getItem('getpaid_userData')
        const userData = this.getUserData();
        userData['companyId'] = companyId;
        localStorage.setItem('getpaid_userData', JSON.stringify(userData));
      })
    );
  }

  getCurrentCompany(): Company {
    const userData = this.getUserData();
    return {
      companyId: userData['companyId'],
      companyName: userData['companyLabel']
    };
  }
  _getLang() {
    const userdata = this.getUserData();
    if (userdata) {
      return userdata['langId'];
    } else {
      return this.translate.getBrowserLang();
    }
  }
  logout(): void {
    this.http.get('/getpaid/api/auth/logout').subscribe(result => {});
    localStorage.removeItem('token');
    localStorage.removeItem('getpaid_userData');
    //this.isLoginSubject.next(false);
  }
}
