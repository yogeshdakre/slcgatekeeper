import { Action } from '@ngrx/store';
import { Company } from '../../models/Company';

export enum CompanyActionTypes {
  SetDefaultCompany = '[Company] setDefault',
  SetDefaultCompanySuccess = '[Company] setDefault Successful',
  SetDefaultCompanyFailed = '[Company] setDefault Failed',
  ChangeCurrentCompany = '[Company] change',
  ChangeCurrentCompanySuccess = '[Company] change Successful',
  ChangeCurrentCompanyFailed = '[Company] change Failed',
  Load = '[Company] load',
  LoadSuccess = '[Company] load successful',
  LoadFailed = '[Company] load Failed'
}

export class SetDefaultCompany implements Action {
  readonly type = CompanyActionTypes.SetDefaultCompany;
  constructor(public payload: { id: number; company: Partial<Company> }) {}
}
export class SetDefaultCompanySuccess implements Action {
  readonly type = CompanyActionTypes.SetDefaultCompanySuccess;
  constructor(public payload: { id: number; company: Partial<Company> }) {}
}
export class SetDefaultCompanyFailed implements Action {
  readonly type = CompanyActionTypes.SetDefaultCompanyFailed;
}

export class ChangeCurrentCompany implements Action {
  readonly type = CompanyActionTypes.ChangeCurrentCompany;
  constructor(public payload: number) {}
}

export class ChangeCurrentCompanySuccess implements Action {
  readonly type = CompanyActionTypes.ChangeCurrentCompanySuccess;
  constructor(public payload: number) {}
}
export class ChangeCurrentCompanyFailed implements Action {
  readonly type = CompanyActionTypes.ChangeCurrentCompanyFailed;
  constructor() {}
}

export class LoadSuccess implements Action {
  readonly type = CompanyActionTypes.LoadSuccess;
  constructor(public payload: { companies: Company[]; currentCompanyId: number }) {}
}
export class Load implements Action {
  readonly type = CompanyActionTypes.Load;
  //constructor(public payload: { companies: Company[]; defaultCompany: Company }) {}
}
export class LoadFailed implements Action {
  readonly type = CompanyActionTypes.LoadFailed;
  //constructor(public payload: { companies: Company[]; defaultCompany: Company }) {}
}

export type CompanyActionsUnion =
  | SetDefaultCompany
  | SetDefaultCompanySuccess
  | SetDefaultCompanyFailed
  | ChangeCurrentCompany
  | ChangeCurrentCompanySuccess
  | ChangeCurrentCompanyFailed
  | Load
  | LoadFailed
  | LoadSuccess;
