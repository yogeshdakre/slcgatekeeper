import { Action } from '@ngrx/store';

export enum NavActionTypes {
  ShowAngularJS = '[Nav] ShowAngularjs',
  HideAngularJS = '[Nav] HideAngularjs',
  ShowAdmin = '[Nav] ShowAdmin',
  ShowAdminSuccess = '[Nav] ShowAdminSuccess',
  ShowAdminFailed = '[Nav] ShowAdminFailed',
  ShowClient = '[Nav] ShowClient',
  ShowClientSuccess = '[Nav] ShowClientSuccess',
  ShowClientFailed = '[Nav] ShowAdminFailed'
}

export class ShowAngularJS implements Action {
  readonly type = NavActionTypes.ShowAngularJS;
  constructor() {}
}

export class HideAngularJS implements Action {
  readonly type = NavActionTypes.HideAngularJS;
  constructor() {}
}
export class ShowAdmin implements Action {
  readonly type = NavActionTypes.ShowAdmin;
  constructor() {}
}
export class ShowAdminFailed implements Action {
  readonly type = NavActionTypes.ShowAdminFailed;
  constructor() {}
}
export class ShowClientFailed implements Action {
  readonly type = NavActionTypes.ShowClientFailed;
  constructor() {}
}
export class ShowAdminSuccess implements Action {
  readonly type = NavActionTypes.ShowAdminSuccess;
  constructor(public payload: { menu: any }) {}
}
export class ShowClient implements Action {
  readonly type = NavActionTypes.ShowClient;
  constructor() {}
}
export class ShowClientSuccess implements Action {
  readonly type = NavActionTypes.ShowClientSuccess;
  constructor(public payload: { menu: any }) {}
}
export type NavActionsUnion =
  | ShowAngularJS
  | HideAngularJS
  | ShowAdmin
  | ShowClient
  | ShowClientSuccess
  | ShowAdminFailed
  | ShowAdminSuccess
  | ShowClientFailed;
