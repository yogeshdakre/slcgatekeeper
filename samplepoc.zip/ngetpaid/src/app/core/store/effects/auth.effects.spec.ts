import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Actions } from '@ngrx/effects';
import { cold, hot, getTestScheduler } from 'jasmine-marbles';
import { Observable } from 'rxjs/observable';
import { empty } from 'rxjs/observable/empty';
import { provideMockActions } from '@ngrx/effects/testing';
import * as testUtil from '../../../../../testing';
import * as AuthActions from '../actions/auth.actions';
import { User, Credential } from '../../models/User';
import { UserService } from '@core/services/user.service';
import { AuthEffects, AUTH_SCHEDULER } from './auth.effects';
//import { asyncData } from '../../../../../testing';

describe('authEffects', () => {
  let effects: AuthEffects;
  let userService: {
    _isAuthenticated: jasmine.Spy;
    getUserData: jasmine.Spy;
    login: jasmine.Spy;
  };
  let router: { navigate: jasmine.Spy };
  let actions$: Observable<any>;

  beforeEach(() => {
    userService = jasmine.createSpyObj('UserService', ['_isAuthenticated', 'getUserData', 'login']);
    router = jasmine.createSpyObj('Router', ['navigate']);
    TestBed.configureTestingModule({
      providers: [
        AuthEffects,
        {
          provide: UserService,
          useValue: userService
        },
        {
          provide: Router,
          useValue: router
        },
        { provide: AUTH_SCHEDULER, useFactory: getTestScheduler },

        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(AuthEffects);
    userService = TestBed.get(UserService);
    actions$ = TestBed.get(Actions);

    //spyOn(routerService, 'navigate').and.callThrough();
  });

  it('login effects with failure', () => {
    const credentials: Credential = { username: 'someOne', password: '' };
    const action = new AuthActions.Login(credentials);
    const completion = new AuthActions.LoginFailure();
    const error = 'Invalid username or password';

    actions$ = hot('-a-----', { a: action });
    const response = cold('-#|', {}, error);
    const expected = cold('-------b', { b: completion });
    userService.login.and.returnValue(response);

    expect(effects.login$).toBeObservable(expected);
  });

  /*
        it('should return a new auth.LoginFailure if the login service throws', () => {
          const credentials: Authenticate = { username: 'someOne', password: '' };
          const action = new Login(credentials);
          const completion = new LoginFailure('Invalid username or password');
          const error = 'Invalid username or password';
    
          actions$.stream = hot('-a---', { a: action });
          const response = cold('-#|', {}, error);
          const expected = cold('--b', { b: completion });
          authService.login = jest.fn(() => response);
    
          expect(effects.login$).toBeObservable(expected);
        });
      });
    
      describe('loginSuccess$', () => {
        it('should dispatch a RouterNavigation action', () => {
          const user = { name: 'User' } as User;
          const action = new LoginSuccess({ user });
    
          actions$.stream = hot('-a---', { a: action });
    
          effects.loginSuccess$.subscribe(() => {
            expect(routerService.navigate).toHaveBeenCalledWith(['/']);
          });
        });
      });
    
      describe('loginRedirect$', () => {
        it('should dispatch a RouterNavigation action when auth.LoginRedirect is dispatched', () => {
          const action = new LoginRedirect();
    
          actions$.stream = hot('-a---', { a: action });
    
          effects.loginRedirect$.subscribe(() => {
            expect(routerService.navigate).toHaveBeenCalledWith(['/login']);
          });
        });
    
        it('should dispatch a RouterNavigation action when auth.Logout is dispatched', () => {
          const action = new Logout();
    
          actions$.stream = hot('-a---', { a: action });
    
          effects.loginRedirect$.subscribe(() => {
            expect(routerService.navigate).toHaveBeenCalledWith(['/login']);
          });
        });*/
});
