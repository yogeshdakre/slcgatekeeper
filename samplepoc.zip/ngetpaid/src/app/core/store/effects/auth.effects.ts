import { Credential } from '@core/models/User';

import { Injectable, Optional, Inject, InjectionToken } from '@angular/core';
import { Action } from '@ngrx/store';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';
import { defer } from 'rxjs/observable/defer';
import { of } from 'rxjs/observable/of';
import { catchError, exhaustMap, mergeMap, map, tap, debounceTime } from 'rxjs/operators';
import { UserService } from '@core/services/user.service';
import { AuthActionTypes, Login, LoginFailure, Logout, LoginSuccess } from '../actions/auth.actions';
import * as CompanyActions from '../actions/company.actions';
import * as NavActions from '../actions/nav.actions';
import { Scheduler } from 'rxjs/Scheduler';
import { async } from 'rxjs/scheduler/async';
import { User } from '../../models/user';
//testing
export const AUTH_SCHEDULER = new InjectionToken<Scheduler>('Auth Scheduler');
@Injectable()
export class AuthEffects {
  /**
   * You inject an optional Scheduler that will be undefined
   * in normal application usage, but its injected here so that you can mock out
   * during testing using the RxJS TestScheduler for simulating passages of time.
   */

  constructor(
    private actions$: Actions,
    private userService: UserService,
    private router: Router,
    @Optional()
    @Inject(AUTH_SCHEDULER)
    private scheduler: Scheduler
  ) {}
  @Effect()
  init$: Observable<Action> = defer<Action>(() => {
    //console.log('xxx');
    if (this.userService._isAuthenticated()) {
      const currentUser = this.userService.getUserData().userLicValue as User;
      console.log('uuuuuuuuuuuuu',currentUser);
      return of<Action>(
        new LoginSuccess({ user: currentUser }),
        new CompanyActions.Load(),
        new NavActions.ShowClient()
      );
    } else {
      return of(new LoginFailure());
    }
  });
  @Effect()
  login$: Observable<Action> = this.actions$.pipe(
    ofType<Login>(AuthActionTypes.Login),
    map(action => action.payload),
    debounceTime(50, this.scheduler || async),
    exhaustMap((auth: Credential) =>
      this.userService.login(auth).pipe(
        mergeMap(result => {
          if (result) {
            const currentUser = this.userService.getUserData().userLicValue as User;
            // this is special case we are loading those inital data.
            return of<Action>(
              new LoginSuccess({ user: currentUser }),
              new CompanyActions.Load(),
              new NavActions.ShowClient()
            );
          } else {
            return of<Action>(new LoginFailure());
          }
        }),
        catchError(error => of(new LoginFailure()))
      )
    )
  );
  @Effect({ dispatch: false })
  LoginSuccess$: Observable<Action> = this.actions$.pipe(
    ofType<Login>(AuthActionTypes.LoginSuccess),
    tap(() => this.router.navigate(['home']))
  );
  @Effect({ dispatch: false })
  loginRedirect$ = this.actions$.pipe(
    ofType(AuthActionTypes.LoginRedirect, AuthActionTypes.Logout),
    tap(authed => {
      this.router.navigate(['/login']);
    })
  );
}
