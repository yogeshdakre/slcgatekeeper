import { ChangeCurrentCompanySuccess, ChangeCurrentCompanyFailed } from '@core/store/actions/company.actions';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Actions } from '@ngrx/effects';
import { cold, hot } from 'jasmine-marbles';
import { Observable } from 'rxjs/observable';
import { empty } from 'rxjs/observable/empty';
import { provideMockActions } from '@ngrx/effects/testing';
import * as testUtil from '../../../../../testing';
import { Load, LoadFailed, LoadSuccess, ChangeCurrentCompany } from '../actions/company.actions';
import { Company } from '../../models/company';
import { UserService } from '@core/services/user.service';
import { CompanyEffects } from './company.effects';
//import { asyncData } from '../../../../../testing';

describe('companyEffects', () => {
  let effects: CompanyEffects;
  let userService: {
    _isAuthenticated: jasmine.Spy;
    getUserData: jasmine.Spy;
    setCurrentCompany: jasmine.Spy;
    getCurrentCompany: jasmine.Spy;
  };
  let actions$: Observable<any>;

  beforeEach(() => {
    userService = jasmine.createSpyObj('userService', [
      '_isAuthenticated',
      'getUserData',
      'setCurrentCompany',
      'getCurrentCompany'
    ]);
    TestBed.configureTestingModule({
      providers: [
        CompanyEffects,
        {
          provide: UserService,
          useValue: userService
        },
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(CompanyEffects);
    userService = TestBed.get(UserService);
    actions$ = TestBed.get(Actions);

    //spyOn(routerService, 'navigate').and.callThrough();
  });

  describe('LoadCompany$', () => {
    it('should return an LoadCompanySuccess action, with company information if login succeeds', () => {
      //const credentials: Authenticate = { username: 'test', password: '' };
      //const user = { name: 'User' } as User;
      const companies: Company[] = [{ companyId: 1, defaultCompany: true, companyName: 'test1' }];
      const action = new Load();

      const completion = new LoadSuccess({
        companies: companies,
        currentCompanyId: 1
      });
      //mock userservice
      userService.getUserData.and.returnValue({ allCompanies: companies });
      userService.getCurrentCompany.and.returnValue({ companyId: 1 });
      userService._isAuthenticated.and.returnValue(true);
      actions$ = hot('-a-', { a: action });
      //const response = cold('-a|', { a: user });
      const expected = cold('-b', { b: completion });
      //authService.login = jest.fn(() => response);
      expect(effects.LoadCompany$).toBeObservable(expected);
    });
    it('should return an LoadCompanyFailed action, with company information if login is failed', () => {
      //const credentials: Authenticate = { username: 'test', password: '' };
      //const user = { name: 'User' } as User;
      const companies: Company[] = [{ companyId: 1, companyName: 'test1' }];
      const action = new Load();

      const completion = new LoadFailed();
      //mock userservice
      userService.getUserData.and.returnValue({ allCompanies: companies });
      userService._isAuthenticated.and.returnValue(false);
      actions$ = hot('-a-', { a: action });
      //const response = cold('-a|', { a: user });
      const expected = cold('-b', { b: completion });
      //authService.login = jest.fn(() => response);
      expect(effects.LoadCompany$).toBeObservable(expected);
    });

    it('should return an ChangeCompanySuccess action', () => {
      //const credentials: Authenticate = { username: 'test', password: '' };
      //const user = { name: 'User' } as User;
      const currentCompanyId = 3;
      const action = new ChangeCurrentCompany(currentCompanyId);

      const completion = new ChangeCurrentCompanySuccess(currentCompanyId);
      //mock userservice
      //userService.getUserData.and.returnValue({ allCompanies: companies });
      userService._isAuthenticated.and.returnValue(true);
      actions$ = hot('-a---', { a: action });
      const response = cold('--a|', { a: {} });
      const expected = cold('---b', { b: completion });
      userService.setCurrentCompany.and.returnValue(response);

      //authService.login = jest.fn(() => response);
      expect(effects.ChangeCurrentCompany$).toBeObservable(expected);
    });

    it('should return an ChangeCompanyFailed action, when userservice return failed', () => {
      //const credentials: Authenticate = { username: 'test', password: '' };
      //const user = { name: 'User' } as User;
      const companies: Company[] = [{ companyId: 1, companyName: 'test1' }, { companyId: 2, companyName: 'test2' }];
      const currentCompanyId = 3;
      const action = new ChangeCurrentCompany(currentCompanyId);

      const completion = new ChangeCurrentCompanyFailed();
      //mock userservice
      //userService.getUserData.and.returnValue({ allCompanies: companies });
      userService._isAuthenticated.and.returnValue(true);
      actions$ = hot('-a---', { a: action });
      const error = '403';
      const response = cold('-#|', {}, error);
      const expected = cold('--b', { b: completion });
      userService.setCurrentCompany.and.returnValue(response);

      //authService.login = jest.fn(() => response);
      expect(effects.ChangeCurrentCompany$).toBeObservable(expected);
    });
    /*
    it('should return a new auth.LoginFailure if the login service throws', () => {
      const credentials: Authenticate = { username: 'someOne', password: '' };
      const action = new Login(credentials);
      const completion = new LoginFailure('Invalid username or password');
      const error = 'Invalid username or password';

      actions$.stream = hot('-a---', { a: action });
      const response = cold('-#|', {}, error);
      const expected = cold('--b', { b: completion });
      authService.login = jest.fn(() => response);

      expect(effects.login$).toBeObservable(expected);
    });
  });

  describe('loginSuccess$', () => {
    it('should dispatch a RouterNavigation action', () => {
      const user = { name: 'User' } as User;
      const action = new LoginSuccess({ user });

      actions$.stream = hot('-a---', { a: action });

      effects.loginSuccess$.subscribe(() => {
        expect(routerService.navigate).toHaveBeenCalledWith(['/']);
      });
    });
  });

  describe('loginRedirect$', () => {
    it('should dispatch a RouterNavigation action when auth.LoginRedirect is dispatched', () => {
      const action = new LoginRedirect();

      actions$.stream = hot('-a---', { a: action });

      effects.loginRedirect$.subscribe(() => {
        expect(routerService.navigate).toHaveBeenCalledWith(['/login']);
      });
    });

    it('should dispatch a RouterNavigation action when auth.Logout is dispatched', () => {
      const action = new Logout();

      actions$.stream = hot('-a---', { a: action });

      effects.loginRedirect$.subscribe(() => {
        expect(routerService.navigate).toHaveBeenCalledWith(['/login']);
      });
    });*/
  });
});
