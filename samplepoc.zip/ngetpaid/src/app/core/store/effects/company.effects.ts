import { ChangeCurrentCompanySuccess } from './../actions/company.actions';
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';
import { Company } from '../../models/company';
import { catchError, exhaustMap, concatMap, map, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { UserService } from '@core/services/user.service';
import {
  CompanyActionTypes,
  SetDefaultCompany,
  ChangeCurrentCompany,
  ChangeCurrentCompanyFailed,
  Load,
  LoadSuccess,
  LoadFailed
} from '../actions/company.actions';
@Injectable()
export class CompanyEffects {
  constructor(private actions: Actions, private userService: UserService) {}
  @Effect()
  // detail about those map https://blog.angularindepth.com/switchmap-bugs-b6de69155524
  LoadCompany$: Observable<Action> = this.actions.pipe(
    ofType<Load>(CompanyActionTypes.Load),
    map(action => {
      //console.log(action);
      if (this.userService._isAuthenticated()) {
        const comps = this.userService.getUserData().allCompanies as Company[];

        const defaultComp = comps.filter(comp => {
          if (comp.defaultCompany) return comp.defaultCompany;
        });

        return new LoadSuccess({
          companies: comps,
          currentCompanyId: this.userService.getCurrentCompany().companyId
        });
      } else {
        return new LoadFailed();
      }
    })
    //map(action => action.payload)
  );
  @Effect()
  ChangeCurrentCompany$: Observable<Action> = this.actions.pipe(
    ofType<ChangeCurrentCompany>(CompanyActionTypes.ChangeCurrentCompany),
    map(action => action.payload),
    concatMap(companyId => {
      return this.userService
        .setCurrentCompany(companyId)
        .pipe(
          map(() => new ChangeCurrentCompanySuccess(companyId)),
          catchError(err => of(new ChangeCurrentCompanyFailed()))
        );
      //console.log(action);
      /*if (this.userService._isAuthenticated()) {
        this.userService.setCurrentCompany(action.payload.companyId).pipe(tap(), catchError());
        //const comps = this.userService.getUserData().allCompanies as Company[];
        return new ChangeCurrentCompanySuccess(action.payload);
      } else {
        return new ChangeCurrentCompanyFailed();
      }*/
    })
    //map(action => action.payload)
  );
}
