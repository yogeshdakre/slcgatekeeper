import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';
import { defer } from 'rxjs/observable/defer';
import { of } from 'rxjs/observable/of';
import { catchError, exhaustMap, mergeMap, map, tap, debounceTime } from 'rxjs/operators';

import * as NavActions from '../actions/nav.actions';
import { User } from '../../models/user';
import { NavigationService } from '@core/services/navigation.service';
@Injectable()
export class NavEffects {
  constructor(private actions$: Actions, private navgationService: NavigationService) {}

  @Effect()
  showAdmin$: Observable<Action> = this.actions$.pipe(
    ofType<NavActions.ShowAdmin>(NavActions.NavActionTypes.ShowAdmin),
    debounceTime(50),
    exhaustMap(() =>
      this.navgationService.load(true).pipe(
        map(result => {
          return new NavActions.ShowAdminSuccess({ menu: result });
        }),
        catchError(error => of(new NavActions.ShowAdminFailed()))
      )
    )
  );
  @Effect()
  showClient$: Observable<Action> = this.actions$.pipe(
    ofType<NavActions.ShowClient>(NavActions.NavActionTypes.ShowClient),
    debounceTime(50),
    exhaustMap(() =>
      this.navgationService.load(false).pipe(
        map(result => {
          return new NavActions.ShowClientSuccess({ menu: result });
        }),
        catchError(error => of(new NavActions.ShowClientFailed()))
      )
    )
  );
}
