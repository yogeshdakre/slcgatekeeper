import { createFeatureSelector, createSelector, ActionReducerMap } from '@ngrx/store';
import * as fromRoot from '../../reducers';

import * as fromCompany from './reducers/company.reducers';
import * as fromAuth from './reducers/auth.reducers';
import * as fromNav from './reducers/nav.reducers';
// this is module state
export interface CoreState {
  company: fromCompany.State;
  auth: fromAuth.State;
  nav: fromNav.State;
}
// let us add to root state
export interface State extends fromRoot.State {
  core: CoreState;
}
export const reducers: ActionReducerMap<CoreState> = {
  company: fromCompany.reducer,
  auth: fromAuth.reducer,
  nav: fromNav.reducer
};
/**
 * The createFeatureSelector function selects a piece of state from the root of the state object.
 * This is used for selecting feature states that are loaded eagerly or lazily.
 */
export const selectCoreState = createFeatureSelector<CoreState>('core');

/**
 * Every reducer module exports selector functions, however child reducers
 * have no knowledge of the overall state tree. To make them usable, we
 * need to make new selectors that wrap them.
 *
 * The createSelector function creates very efficient selectors that are memoized and
 * only recompute when arguments change. The created selectors can also be composed
 * together to select different pieces of state.
 */

export const getCompany = createSelector(selectCoreState, state => state.company);
export const selectCurrentCompanId = createSelector(getCompany, state => state.currentCompanyId);
export const {
  // select the array of Company ids
  selectIds: selectCompanyIds,
  // select the dictionary of Company entities
  selectEntities: selectCompanyEntities,
  // select the array of Companys
  selectAll: selectAllCompany,
  // select the total Company count
  selectTotal: selectCompanyTotal
} = fromCompany.adapter.getSelectors(getCompany);

export const selectCurrentCompany = createSelector(
  selectCompanyEntities,
  selectCurrentCompanId,
  (entities, selectedId) => {
    return selectedId && entities[selectedId];
  }
);
export const getAuth = createSelector(selectCoreState, state => state.auth);
export const getNav = createSelector(selectCoreState, state => state.nav);
export const getShowAngularJS = createSelector(getNav, state => state.isAngularJS);
export const getUser = createSelector(getAuth, fromAuth.getUser);
export const getLoggedIn = createSelector(getAuth, fromAuth.getLoggedIn);
export const getLoginPending = createSelector(getAuth, fromAuth.getPending);
export const getAdmin = createSelector(getNav, state => state.isAdmin);
export const getMenu = createSelector(getNav, state => state.menu);
