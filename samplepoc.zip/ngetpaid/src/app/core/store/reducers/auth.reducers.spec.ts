import { reducer } from './auth.reducers';
import * as fromAuth from './auth.reducers';
import { Login, LoginSuccess, Logout, LoginFailure } from '../actions/auth.actions';
import { Credential, User } from '../../models/user';

describe('AuthReducer', () => {
  describe('undefined action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = reducer(undefined, action);

      //console.log(result);
      expect(result.loggedIn).toBe(false);
      expect(result.user).toBeNull();
    });
  });

  describe('wrong login payload', () => {
    it('should NOT authenticate a user', () => {
      const user = { username: 'someUserName' } as Credential;
      const createAction = new Login(user);

      const expectedResult = { ...fromAuth.initialState, pending: true };

      const result = reducer(fromAuth.initialState, createAction);

      expect(result).toEqual(expectedResult);
    });
  });

  describe('LOGIN_SUCCESS', () => {
    it('should add a user set loggedIn to true in auth state', () => {
      const user = new User();
      user.namedUser = 'jimmy';
      const createAction = new LoginSuccess({ user });

      const expectedResult = { loggedIn: true, user: user, pending: false } as fromAuth.State;

      const result = reducer(fromAuth.initialState, createAction);

      expect(result).toEqual(expectedResult);
    });
  });
  describe('LOGIN_FAILED', () => {
    it('should add a user set loggedIn to true in auth state', () => {
      const user = new User();
      user.namedUser = 'jimmy';
      const createAction = new LoginFailure();

      const expectedResult = { loggedIn: false, user: null, pending: false } as fromAuth.State;

      const result = reducer(fromAuth.initialState, createAction);

      expect(result).toEqual(expectedResult);
    });
  });
  describe('LOGOUT', () => {
    it('should logout a user', () => {
      const user = new User();
      user.namedUser = 'jimmy';
      const initialState = { loggedIn: true, user: user } as fromAuth.State;
      const createAction = new Logout();

      const expectedResult = fromAuth.initialState;

      const result = reducer(initialState, createAction);

      expect(result).toEqual(expectedResult);
    });
  });
});
