import { User } from '../../models/user';
import { AuthActionsUnion, AuthActionTypes } from './../actions/auth.actions';

export interface State {
  // is a user authenticated?
  loggedIn: boolean;
  // if authenticated, there should be a user object
  user: User | null;
  pending: boolean;
}

export const initialState: State = {
  loggedIn: false,
  user: null,
  pending: false
};

export function reducer(state = initialState, action: AuthActionsUnion): State {
  switch (action.type) {
    case AuthActionTypes.Login: {
      return { ...state, pending: true };
    }
    case AuthActionTypes.LoginSuccess: {
      return {
        ...state,
        loggedIn: true,
        user: action.payload.user,
        pending: false
      };
    }
    case AuthActionTypes.LoginFailure: {
      // this is equal to return state, ... is spread operator
      return {
        ...state,
        pending: false
      };
    }
    case AuthActionTypes.LoginRedirect: {
      return {
        ...state,
        loggedIn: false
      };
    }
    case AuthActionTypes.Logout: {
      return initialState;
    }

    default: {
      return state;
    }
  }
}

export const getLoggedIn = (state: State) => state.loggedIn;
export const getUser = (state: State) => state.user;
export const getPending = (state: State) => state.pending;
