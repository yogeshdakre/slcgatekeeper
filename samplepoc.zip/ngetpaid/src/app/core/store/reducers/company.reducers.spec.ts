import { reducer } from './company.reducers';
import * as fromCompany from './company.reducers';
import * as companyActions from '../actions/company.actions';
import { Company } from '../../models/company';

describe('CompanyReducer', () => {
  const company1 = { companyId: 1, companyName: 'test1' } as Company;
  const company2 = { companyId: 2, companyName: 'test2' } as Company;
  it(' undefined action should return the default state', () => {
    const action = {} as any;

    const result = reducer(undefined, action);

    //console.log(result);
    expect(result.currentCompanyId).toBeNull();
    //result.entities.keys();
    expect(result.entities).toEqual(Object({}));
  });

  it('should add all companys and with currentCompanyId ', () => {
    const createAction = new companyActions.LoadSuccess({ companies: [company1, company2], currentCompanyId: 1 });

    const expectedResult = {
      ...fromCompany.initialState,
      ids: [1, 2],
      entities: {
        [company1.companyId]: company1,
        [company2.companyId]: company2
      },
      currentCompanyId: 1
    } as fromCompany.State;

    const result = reducer(fromCompany.initialState, createAction);

    expect(result).toEqual(expectedResult);
  });

  it('change current company ', () => {
    const createAction = new companyActions.ChangeCurrentCompanySuccess(2);

    const expectedResult = {
      ...fromCompany.initialState,

      currentCompanyId: 2
    } as fromCompany.State;

    const result = reducer(fromCompany.initialState, createAction);

    expect(result).toEqual(expectedResult);
  });
  it('change current company failed ', () => {
    const createAction = new companyActions.ChangeCurrentCompanyFailed();

    const result = reducer(fromCompany.initialState, createAction);

    expect(result).toEqual(fromCompany.initialState);
  });
  it('set default company ', () => {
    const createAction = new companyActions.LoadSuccess({ companies: [company1, company2], currentCompanyId: 1 });

    const result = reducer(fromCompany.initialState, createAction);
    const companyExpect = { ...company1, defaultCompany: true } as Company;
    const companyINput = { defaultCompany: true } as Partial<Company>;

    const expectedResult = {
      ...fromCompany.initialState,
      ids: [1, 2],
      entities: { [company1.companyId]: companyExpect, [company2.companyId]: company2 },
      currentCompanyId: 1
    } as fromCompany.State;

    const changeAction = new companyActions.SetDefaultCompanySuccess({ id: 1, company: companyINput });
    const result2 = reducer(result, changeAction);

    expect(result2).toEqual(expectedResult);
  });

  /*
  describe('LOGIN_SUCCESS', () => {
    it('should add a user set loggedIn to true in auth state', () => {
      const user = new User();
      user.namedUser = 'jimmy';
      const createAction = new LoginSuccess({ user });

      const expectedResult = { loggedIn: true, user: user, pending: false } as fromAuth.State;

      const result = reducer(fromAuth.initialState, createAction);

      expect(result).toEqual(expectedResult);
    });
  });
  describe('LOGIN_FAILED', () => {
    it('should add a user set loggedIn to true in auth state', () => {
      const user = new User();
      user.namedUser = 'jimmy';
      const createAction = new LoginFailure();

      const expectedResult = { loggedIn: false, user: null, pending: false } as fromAuth.State;

      const result = reducer(fromAuth.initialState, createAction);

      expect(result).toEqual(expectedResult);
    });
  });
  describe('LOGOUT', () => {
    it('should logout a user', () => {
      const user = new User();
      user.namedUser = 'jimmy';
      const initialState = { loggedIn: true, user: user } as fromAuth.State;
      const createAction = new Logout();

      const expectedResult = fromAuth.initialState;

      const result = reducer(initialState, createAction);

      expect(result).toEqual(expectedResult);
    });
  });*/
});
