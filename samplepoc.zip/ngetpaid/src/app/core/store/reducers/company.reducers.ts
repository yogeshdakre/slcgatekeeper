import { Company } from '../../models/company';
import { CompanyActionsUnion, CompanyActionTypes } from './../actions/company.actions';
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
/**
 * @ngrx/entity provides a predefined interface for handling
 * a structured dictionary of records. This interface
 * includes an array of ids, and a dictionary of the provided
 * model type by id. This interface is extended to include
 * any additional interface properties.
 */
export interface State extends EntityState<Company> {
  // the current Company
  currentCompanyId: number;
}

/**
 * createEntityAdapter creates an object of many helper
 * functions for single or multiple operations
 * against the dictionary of records. The configuration
 * object takes a record id selector function and
 * a sortComparer option which is set to a compare
 * function if the records are to be sorted.
 */
export const adapter: EntityAdapter<Company> = createEntityAdapter<Company>({
  selectId: (company: Company) => company.companyId,
  sortComparer: false
});

/**
 * getInitialState returns the default initial state
 * for the generated entity state. Initial state
 * additional properties can also be defined.
 */
export const initialState: State = adapter.getInitialState({ currentCompanyId: null });

export function reducer(state = initialState, action: CompanyActionsUnion): State {
  switch (action.type) {
    case CompanyActionTypes.ChangeCurrentCompanySuccess: {
      return { ...state, currentCompanyId: action.payload };
    }
    case CompanyActionTypes.SetDefaultCompanySuccess: {
      return adapter.updateOne({ id: action.payload.id, changes: action.payload.company }, { ...state });
    }

    case CompanyActionTypes.LoadSuccess: {
      return adapter.addAll(action.payload.companies, {
        ...state,
        currentCompanyId: action.payload.currentCompanyId
      });
    }

    default: {
      return state;
    }
  }
}
