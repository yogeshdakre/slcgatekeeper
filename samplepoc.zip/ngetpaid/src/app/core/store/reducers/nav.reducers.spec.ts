import { ShowAdminSuccess } from '@core/store/actions/nav.actions';
import { reducer } from './nav.reducers';
import * as fromNav from './nav.reducers';
import * as navActions from '../actions/nav.actions';

describe('NavReducer', () => {
  it(' undefined action should return the default state', () => {
    const action = {} as any;

    const result = reducer(undefined, action);

    //console.log(result);
    expect(result.isAdmin).toBeFalsy();
    //result.entities.keys();
    expect(result.isAngularJS).toBeFalsy();
  });

  it('show admin ', () => {
    const menu = {} as any;
    const createAction = new navActions.ShowAdminSuccess({ menu: {} });

    const expectedResult = { ...fromNav.initialState, isAdmin: true, menu: {} } as fromNav.State;

    const result = reducer(fromNav.initialState, createAction);

    expect(result).toEqual(expectedResult);
  });

  it('hide admin ', () => {
    const createAction = new navActions.ShowClient();

    const expectedResult = {
      ...fromNav.initialState,
      isAdmin: false
    } as fromNav.State;

    const result = reducer(fromNav.initialState, createAction);

    expect(result).toEqual(expectedResult);
  });

  it('show angularjs ', () => {
    const createAction = new navActions.ShowAngularJS();

    const expectedResult = {
      ...fromNav.initialState,
      isAngularJS: true
    } as fromNav.State;

    const result = reducer(fromNav.initialState, createAction);

    expect(result).toEqual(expectedResult);
  });

  it('hide angularjs ', () => {
    const createAction = new navActions.HideAngularJS();

    const expectedResult = {
      ...fromNav.initialState,
      isAngularJS: false
    } as fromNav.State;

    const result = reducer(fromNav.initialState, createAction);

    expect(result).toEqual(expectedResult);
  });
  /*
  it('change current company ', () => {
    const createAction = new companyActions.ChangeCurrentCompanySuccess(2);

    const expectedResult = {
      ...fromCompany.initialState,

      currentCompanyId: 2
    } as fromCompany.State;

    const result = reducer(fromCompany.initialState, createAction);

    expect(result).toEqual(expectedResult);
  });
  it('change current company failed ', () => {
    const createAction = new companyActions.ChangeCurrentCompanyFailed();

    const result = reducer(fromCompany.initialState, createAction);

    expect(result).toEqual(fromCompany.initialState);
  });
  it('set default company ', () => {
    const createAction = new companyActions.LoadSuccess({ companies: [company1, company2], currentCompanyId: 1 });

    const result = reducer(fromCompany.initialState, createAction);
    const companyExpect = { ...company1, defaultCompany: true } as Company;
    const companyINput = { defaultCompany: true } as Partial<Company>;

    const expectedResult = {
      ...fromCompany.initialState,
      ids: [1, 2],
      entities: { [company1.companyId]: companyExpect, [company2.companyId]: company2 },
      currentCompanyId: 1
    } as fromCompany.State;

    const changeAction = new companyActions.SetDefaultCompanySuccess({ id: 1, company: companyINput });
    const result2 = reducer(result, changeAction);

    expect(result2).toEqual(expectedResult);
  });

  */
});
