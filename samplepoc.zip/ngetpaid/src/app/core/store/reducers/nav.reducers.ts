import { ShowAdminSuccess } from '@core/store/actions/nav.actions';
import { User } from '../../models/user';
import { NavActionsUnion, NavActionTypes, ShowAngularJS, HideAngularJS } from './../actions/nav.actions';

export interface State {
  isAngularJS: boolean;
  isAdmin: boolean;
  menu: any;
}

export const initialState: State = {
  isAngularJS: false,
  isAdmin: false,
  menu: null
};

export function reducer(state = initialState, action: NavActionsUnion): State {
  switch (action.type) {
    case NavActionTypes.ShowAngularJS: {
      return { ...state, isAngularJS: true };
    }
    case NavActionTypes.HideAngularJS: {
      return { ...state, isAngularJS: false };
    }
    case NavActionTypes.ShowAdminSuccess: {
      return { ...state, isAdmin: true, menu: action.payload.menu };
    }
    case NavActionTypes.ShowClientSuccess: {
      return { ...state, isAdmin: false, menu: action.payload.menu };
    }

    default: {
      return state;
    }
  }
}
