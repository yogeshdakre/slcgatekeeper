import { Component, OnInit, Input } from "@angular/core";
import {
  TranslateService,
  TranslationChangeEvent,
  LangChangeEvent,
  TranslatePipe
} from "@ngx-translate/core";
import { IAlert } from '../models/ialert';

@Component({
  selector: "app-alertmessage",
  templateUrl: "./alertmessage.component.html",
  styleUrls: ["./alertmessage.component.scss"]
})
export class AlertmessageComponent implements OnInit {
  @Input()
  public alerts: Array<IAlert> = [];
  public loglevel = {
    "": "primary"
    , "info": "primary"
    , "success": "Success"
    , "debug": "accent"
    , "warn": "warn"
    , "warning": "warn"
    , "error": "Danger"
    , "undefined": "primary"
  };
  constructor() {

  }


  ngOnInit() { }
}

