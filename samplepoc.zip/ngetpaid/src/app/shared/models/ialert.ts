export interface IAlert {
    id: number;
    type: string;
    message: string;
    alreadytranslated?: true;
    title?: string;
    visible?: true
}