import { Component } from "@angular/core";

@Component({
  selector: "app-test",
  template: `
    <ruf-page-header title="Welcome to RUF!" description="FIS Responsive UI Framework">
      <ruf-page-header-icon><mat-icon fisIcon="approval"></mat-icon></ruf-page-header-icon>
    </ruf-page-header>
    <section rufPaddingHorizontal>
      <p>
        If you haven't done so already, go install
        <a href="https://augury.angular.io/" target="_blank">Augury</a>.
        It's a great tool for debugging and inspecting Angular applications.
      </p>
      <p>
        Visit <a href="https://www.csa.sungard.com/wiki/display/html/RUF+Documentation" target="_blank">RUF documentation</a>
        for more details.
      </p>
    </section>
	`
})
export class WelcomeComponent {}
