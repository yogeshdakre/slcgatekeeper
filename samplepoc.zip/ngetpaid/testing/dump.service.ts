import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class DumpService {
  ROOT_URL = `http://gpcollect.com`;

  constructor(private http: HttpClient) {}

  getRequset() {
    return this.http.get(`${this.ROOT_URL}/gets`);
  }
}
