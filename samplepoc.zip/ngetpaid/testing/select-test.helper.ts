import { By } from '@angular/platform-browser';
import { OverlayContainer } from '@angular/cdk/overlay';
import { inject, ComponentFixture, flush } from '@angular/core/testing';

export class SelectTestHelper {
  private _container: OverlayContainer;
  private _containerElement: HTMLElement;
  private _trigger: HTMLElement;

  public constructor(private _fixture: ComponentFixture<any>, private _formControlName: string) {
    inject([OverlayContainer], (oc: OverlayContainer) => {
      this._container = oc;
      this._containerElement = oc.getContainerElement();
    })();
  }

  public trigger() {
    this._fixture.detectChanges();
    this._trigger = this._fixture.debugElement.query(
      By.css('[formcontrolname="companyList"] .mat-select-trigger')
    ).nativeElement;
    this._trigger.click();
    this._fixture.detectChanges();
  }

  public getOptions(): HTMLElement[] {
    return Array.from(this._containerElement.querySelectorAll('mat-option') as NodeListOf<HTMLElement>);
  }

  public selectOption(option: HTMLElement) {
    option.click();
    this._fixture.detectChanges();
    this._trigger.click();
    this._fixture.detectChanges();
    flush();
  }

  public selectOptionByKey(options: HTMLElement[], key: string) {
    options.forEach((option: HTMLElement) => {
      if (option.innerText.trim() === key) {
        this.selectOption(option);
      }
    });
  }

  public cleanup() {
    this._container.ngOnDestroy();
  }
}
